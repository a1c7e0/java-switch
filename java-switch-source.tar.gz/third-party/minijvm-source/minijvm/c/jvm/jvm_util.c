//
// Created by gust on 2017/8/8.
//


#include <stdarg.h>
#include <limits.h>
#include <math.h>
#include <sys/stat.h>
#include "jvm.h"

#include "../utils/miniz_wrapper.h"
#include "jvm_util.h"
#include "garbage.h"
#include "jdwp.h"

#if __JVM_PRI_ALLOC__


#endif


//==================================================================================
static s64 nano_sec_start_at = 0;

/**
 * =============================== JClass ==============================
 */

s32 classes_loaded_count_unsafe(MiniJVM *jvm) {
    s32 i, count = 0;
    for (i = 0; i < jvm->classloaders->length; i++) {
        PeerClassLoader *pcl = arraylist_get_value_unsafe(jvm->classloaders, i);
        count += (s32) pcl->classes->entries;
    }
    return count;
}

JClass *classes_get_c(MiniJVM *jvm, Instance *jloader, c8 const *clsName) {
    Utf8String *ustr = utf8_create_c(clsName);
    JClass *clazz = classes_get(jvm, jloader, ustr);
    utf8_destroy(ustr);
    return clazz;
}

JClass *classes_get(MiniJVM *jvm, Instance *jloader, Utf8String *clsName) {
    JClass *cl = NULL;
    if (clsName) {
        PeerClassLoader *pcl = jloader ? classLoaders_find_by_instance(jvm, jloader) : jvm->boot_classloader;
        if (pcl) {
            cl = hashtable_get(pcl->classes, clsName);
            if (!cl) {
                if (jloader) {
                    cl = classes_get(jvm, pcl->parent, clsName);
                }
            }
        } else {
            jvm_printf("classloader has removed too early, class:%s\n", utf8_cstr(clsName));
        }
    }
    return cl;
}

JClass *classes_load_get_without_resolve(Instance *jloader, Utf8String *ustr, Runtime *runtime) {
    if (!ustr)return NULL;
    MiniJVM *jvm = runtime->jvm;
    JClass *cl;
    spin_lock(&jvm->lock_cloader); //fast lock
    if (utf8_index_of(ustr, '.') >= 0) utf8_replace_c(ustr, ".", "/");
    spin_unlock(&jvm->lock_cloader);
    cl = classes_get(jvm, jloader, ustr);
    if (!cl) {
        vm_share_lock(jvm); //slow lock
        cl = classes_get(jvm, jloader, ustr);
        if (!cl) {
            cl = load_class(jloader, ustr, runtime);
        }
        vm_share_unlock(jvm);
    }
    return cl;
}

JClass *classes_load_get_with_resolve(Instance *jloader, Utf8String *ustr, Runtime *runtime) {
    JClass *cl = classes_load_get_without_resolve(jloader, ustr, runtime);
    if (cl && cl->status < CLASS_STATUS_PREPARED) {
        class_prepar(jloader, cl, runtime);
    }
    return cl;
}

JClass *classes_load_get_with_clinit_c(Instance *jloader, c8 const *pclassName, Runtime *runtime) {
    Utf8String *ustr = utf8_create_c(pclassName);
    JClass *clazz = classes_load_get_with_clinit(jloader, ustr, runtime);
    utf8_destroy(ustr);
    return clazz;
}

JClass *classes_load_get_with_clinit(Instance *jloader, Utf8String *ustr, Runtime *runtime) {
    JClass *cl = classes_load_get_without_resolve(jloader, ustr, runtime);
    if (cl && cl->status < CLASS_STATUS_CLINITED) {
        class_clinit(cl, runtime);
    }
    return cl;
}

s32 classes_put(MiniJVM *jvm, JClass *clazz) {
    if (clazz) {
        //jvm_printf("PUT in classloader %s <- %s\n", clazz->jloader ? utf8_cstr(clazz->jloader->mb.clazz->name) : "NULL", utf8_cstr(clazz->name));
        PeerClassLoader *pcl = classLoaders_find_by_instance(jvm, clazz->jloader);
        hashtable_put(pcl->classes, clazz->name, clazz);
        return 0;
    }
    return -1;
}

s32 classes_remove(MiniJVM *jvm, JClass *clazz) {
    if (clazz) {
        //jvm_printf("PUT in classloader %s <- %s\n", clazz->jloader ? utf8_cstr(clazz->jloader->mb.clazz->name) : "NULL", utf8_cstr(clazz->name));
        PeerClassLoader *pcl = classLoaders_find_by_instance(jvm, clazz->jloader);
        if (pcl) {
            if (jdwp_client_count(jvm->jdwpserver))event_on_class_unload(jvm->jdwpserver, clazz);
#if _JVM_DEBUG_SLOW_CALL_PROFILE
            profile_slow_call_unregister_class(jvm, clazz);
            profile_slow_call_remove_class_cache(jvm, clazz->name);
#endif
            hashtable_remove(pcl->classes, clazz->name, 0);
        }
        return 0;
    }
    return -1;
}

JClass *primitive_class_create_get(Runtime *runtime, Utf8String *ustr) {
    MiniJVM *jvm = runtime->jvm;
    JClass *cl = classes_get(jvm, NULL, ustr);
    if (!cl) {
        Utf8String *typename = utf8_create_copy(ustr);
        vm_share_lock(jvm);
        cl = class_create(runtime);
        if (!cl) {
            vm_share_unlock(jvm);
            utf8_destroy(typename);
            return NULL;
        }
        cl->name = typename;
        cl->is_primitive = 1;
        cl->jloader = NULL; //system classloader
        classes_put(jvm, cl);
        class_build_vtable(cl);
        if (jdwp_client_count(jvm->jdwpserver) && cl)event_on_class_prepare(jvm->jdwpserver, runtime, cl);
        //        gc_obj_hold(jvm->collector, cl);
        vm_share_unlock(jvm);
#if _JVM_DEBUG_LOG_LEVEL > 2
        jvm_printf("load class (%016llx load %016llx):  %s \n", (s64) (intptr_t) NULL, (s64) (intptr_t) cl, utf8_cstr(cl->name));
#endif
    }
    return cl;
}

JClass *arraytype_get_by_desc(Runtime *runtime, Instance *jloader, Utf8String *desc) {
    if (desc && desc->length && utf8_char_at(desc, 0) == '[') {
        Utf8String *typename = utf8_create_part(desc, 1, desc->length - 1);
        JClass *typec = NULL;
        if (utf8_char_at(typename, 0) == '[') {
            typec = array_class_create_get(runtime, jloader, typename);
        } else if (utf8_char_at(typename, 0) == 'L') {
            //class:  Ljava/lang/Object;
            utf8_remove(typename, 0); //remove "L"
            utf8_remove(typename, typename->length - 1); //remove ";"
            typec = classes_load_get_with_resolve(jloader, typename, runtime);
        } else {
            //primitive : I
            c8 *cname = getDataTypeFullName(utf8_char_at(typename, 0));
            utf8_clear(typename);
            utf8_append_c(typename, cname);
            typec = primitive_class_create_get(runtime, typename);
        }
        utf8_destroy(typename);
        return typec;
    }
    return NULL;
}

JClass *array_class_create_get(Runtime *runtime, Instance *jloader, Utf8String *desc) {
    if (desc && desc->length && utf8_char_at(desc, 0) == '[') {
        MiniJVM *jvm = runtime->jvm;
        JClass *clazz = classes_get(jvm, jloader, desc);
        if (!clazz) {
            JClass *component_class = arraytype_get_by_desc(runtime, jloader, desc);
            if (!component_class) return NULL;
            vm_share_lock(jvm);
            clazz = classes_get(jvm, jloader, desc); //maybe other thread created
            if (!clazz) {
                clazz = class_create(runtime);
                if (!clazz) {
                    vm_share_unlock(jvm);
                    return NULL;
                }
                clazz->mb.arr_type_index = getDataTypeIndex(utf8_char_at(desc, 1));
                clazz->name = utf8_create_copy(desc);
                clazz->superclass = classes_get_c(jvm, NULL, STR_CLASS_JAVA_LANG_OBJECT);
                clazz->component_class = component_class;
                // Array classes use the defining loader of their immediate component.
                clazz->jloader = component_class->jloader;

                //                gc_obj_hold(jvm->collector, clazz);
                classes_put(jvm, clazz);
                class_build_vtable(clazz);
                if (jdwp_client_count(jvm->jdwpserver) && clazz)event_on_class_prepare(jvm->jdwpserver, runtime, clazz);
#if _JVM_DEBUG_LOG_LEVEL > 2
                jvm_printf("load class (%016llx load %016llx):  %s \n", (s64) (intptr_t) clazz->jloader, (s64) (intptr_t) clazz, utf8_cstr(clazz->name));
#endif
            }
            vm_share_unlock(jvm);
        }
        return clazz;
    }
    return NULL;
}

/**
 * array class get accepted name :
 *
 *    7                     -> [D
 *
 * @param runtime
 * @param name
 * @return
 */
JClass *array_class_get_by_index(Runtime *runtime, s32 typeIdx) {
    JClass *clazz = NULL;
    ShortCut *cache = &runtime->jvm->shortcut;
    if (cache->array_classes[typeIdx] == NULL) {
        Utf8String *ustr = utf8_create_c("[");
        utf8_insert(ustr, ustr->length, getDataTypeTag(typeIdx));
        clazz = cache->array_classes[typeIdx] = array_class_create_get(runtime, NULL, ustr);
        utf8_destroy(ustr);
    } else {
        clazz = cache->array_classes[typeIdx];
    }
    return clazz;
}


/**
 * array class get accepted name :
 *
 *    [D                    -> [[D
 *    java/lang/String      -> [Ljava/lang/String;
 *    Ljava/lang/Float;     -> [Ljava/lang/Float;
 *
 *
 * @param runtime
 * @param name
 * @return
 */
JClass *array_class_get_by_name(Runtime *runtime, Instance *jloader, Utf8String *name) {
    JClass *clazz = NULL;
    if (name) {
        Utf8String *ustr = utf8_create_c("[");
        if (!isDataReferByTag(utf8_char_at(name, 0))) {
            //not : L [
            if (!isDataReferByTag(utf8_char_at(name, 0))) {
                utf8_append_c(ustr, "L");
            }
            utf8_append(ustr, name);
            if (utf8_char_at(name, name->length - 1) != ';') {
                utf8_append_c(ustr, ";");
            }
        } else {
            utf8_append(ustr, name);
        }
        clazz = array_class_create_get(runtime, jloader, ustr);
        utf8_destroy(ustr);
    }
    return clazz;
}

/**
 * =============================== threadlist ==============================
 */

Runtime *threadlist_get(MiniJVM *jvm, s32 i) {
    Runtime *r = NULL;
    spin_lock(&jvm->thread_list->spinlock);
    if (i < jvm->thread_list->length) {
        r = (Runtime *) arraylist_get_value_unsafe(jvm->thread_list, i);
    }
    spin_unlock(&jvm->thread_list->spinlock);
    return r;
}

void threadlist_remove(Runtime *runtime) {
    if (runtime)arraylist_remove(runtime->jvm->thread_list, runtime);
}

void threadlist_add(Runtime *runtime) {
    if (runtime)arraylist_push_back(runtime->jvm->thread_list, runtime);
}

s32 threadlist_count_none_daemon(MiniJVM *jvm) {
    spin_lock(&jvm->thread_list->spinlock);
    s32 count = 0;
    s32 i;
    for (i = 0; i < jvm->thread_list->length; i++) {
        Runtime *r = (Runtime *) arraylist_get_value_unsafe(jvm->thread_list, i);
        Instance *ins = r->thrd_info->jthread;
        s32 daemon = jthread_get_daemon_value(ins, r);
        if (!daemon && r->thrd_info->thread_status != THREAD_STATUS_ZOMBIE) {
            count++;
        }
    }
    spin_unlock(&jvm->thread_list->spinlock);
    return count;
}

s32 threadlist_count_active(MiniJVM *jvm) {
    spin_lock(&jvm->thread_list->spinlock);
    s32 count = 0;
    s32 i;
    for (i = 0; i < jvm->thread_list->length; i++) {
        Runtime *r = (Runtime *) arraylist_get_value_unsafe(jvm->thread_list, i);
        Instance *ins = r->thrd_info->jthread;
        s32 daemon = jthread_get_daemon_value(ins, r);
        if (!daemon && r->thrd_info->thread_status != THREAD_STATUS_ZOMBIE) {
            count++;
        }
    }
    spin_unlock(&jvm->thread_list->spinlock);
    return count;
}

s64 threadlist_sum_heap(MiniJVM *jvm) {
    s64 hsize = 0;
    spin_lock(&jvm->thread_list->spinlock);
    s32 i;
    for (i = 0; i < jvm->thread_list->length; i++) {
        Runtime *r = arraylist_get_value_unsafe(jvm->thread_list, i);
        hsize += r->thrd_info->objs_heap_of_thread;
    }
    spin_unlock(&jvm->thread_list->spinlock);
    return hsize;
}

void thread_stop_all(MiniJVM *jvm) {
    spin_lock(&jvm->thread_list->spinlock);
    s32 i;
    for (i = 0; i < jvm->thread_list->length; i++) {
        Runtime *r = arraylist_get_value_unsafe(jvm->thread_list, i);

        //jthread_suspend(r);
        r->thrd_info->no_pause = 1;
        r->thrd_info->is_stop = 1; //stop thread that's sleeping state
        /* Keep the list lock while resolving the Runtime pointer. The old
         * second unlocked pass raced GC/thread finalization and could call
         * jthread_wakeup through a freed Runtime. The monitor acquisition in
         * jthread_wakeup is bounded (20ms), so it cannot permanently pin the
         * list lock. */
        jthread_wakeup(r);
    }
    spin_unlock(&jvm->thread_list->spinlock);
}


void thread_lock_init(ThreadLock *lock) {
    if (lock) {
        cnd_init(&lock->thread_cond);
        mtx_init(&lock->mutex_lock, mtx_recursive | mtx_timed);
        lock->owner_thread = NULL;
        lock->recursion_count = 0;
    }
}

void thread_lock_dispose(ThreadLock *lock) {
    if (lock) {
        cnd_destroy(&lock->thread_cond);
        mtx_destroy(&lock->mutex_lock);
    }
}


s32 vm_share_trylock(MiniJVM *jvm) {
    return mtx_trylock(&jvm->threadlock.mutex_lock);
}

void vm_share_lock(MiniJVM *jvm) {
    mtx_lock(&jvm->threadlock.mutex_lock);
}

void vm_share_unlock(MiniJVM *jvm) {
    mtx_unlock(&jvm->threadlock.mutex_lock);
}

void vm_share_wait(MiniJVM *jvm) {
    cnd_wait(&jvm->threadlock.thread_cond, &jvm->threadlock.mutex_lock);
}

void vm_share_timedwait(MiniJVM *jvm, s64 ms) {
    struct timespec t;
    timespec_get(&t, TIME_UTC);
    t.tv_sec += ms / 1000;
    t.tv_nsec += (ms % 1000) * 1000000;
    s32 ret = cnd_timedwait(&jvm->threadlock.thread_cond, &jvm->threadlock.mutex_lock, &t);
    //    if (ret == ETIMEDOUT) {
    //        s32 debug = 1;
    //    }
}

void vm_share_notify(MiniJVM *jvm) {
    cnd_signal(&jvm->threadlock.thread_cond);
}

void vm_share_notifyall(MiniJVM *jvm) {
    cnd_broadcast(&jvm->threadlock.thread_cond);
}

/**
 * 交换高低位，little endian 和 big endian 互转时用到
 * @param ptr addr
 * @param size len
 */
void swap_endian_little_big(u8 *ptr, s32 size) {
    s32 i;
    for (i = 0; i < size / 2; i++) {
        u8 tmp = ptr[i];
        ptr[i] = ptr[size - 1 - i];
        ptr[size - 1 - i] = tmp;
    }
}

/*
boolean   4
char  5
float  6
double 7
unsigned char 8
short   9
int  10
long  11
 reference 12
 */
s32 getDataTypeIndex(c8 ch) {
    switch (ch) {
        case 'I':
            return 10;
        case 'L':
        case '[':
            return 12;
        case 'C':
            return 5;
        case 'B':
            return 8;
        case 'Z':
            return 4;
        case 'J':
            return 11;
        case 'F':
            return 6;
        case 'D':
            return 7;
        case 'S':
            return 9;
        default:
            jvm_printf("datatype not found %c\n", ch);
    }
    return 0;
}

c8 *getDataTypeFullName(c8 ch) {
    switch (ch) {
        case 'I':
            return "int";
        case 'C':
            return "char";
        case 'B':
            return "byte";
        case 'Z':
            return "boolean";
        case 'J':
            return "long";
        case 'F':
            return "float";
        case 'D':
            return "double";
        case 'S':
            return "short";
    }
    return NULL;
}

u8 getDataTypeTagByName(Utf8String *name) {
    if (utf8_equals_c(name, "int")) {
        return 'I';
    }
    if (utf8_equals_c(name, "long")) {
        return 'J';
    }
    if (utf8_equals_c(name, "char")) {
        return 'C';
    }
    if (utf8_equals_c(name, "byte")) {
        return 'B';
    }
    if (utf8_equals_c(name, "boolean")) {
        return 'Z';
    }
    if (utf8_equals_c(name, "short")) {
        return 'S';
    }
    if (utf8_equals_c(name, "double")) {
        return 'D';
    }
    if (utf8_equals_c(name, "float")) {
        return 'F';
    }
    return 'V';
}


u8 getDataTypeTag(s32 index) {
    return DATA_TYPE_STR[index];
}

s32 isDataReferByTag(c8 c) {
    if (c == 'L' || c == '[') {
        return 1;
    }
    return 0;
}

s32 isData8ByteByTag(c8 c) {
    if (c == 'D' || c == 'J') {
        return 1;
    }
    return 0;
}

s32 isDataReferByIndex(s32 index) {
    if (index == DATATYPE_REFERENCE || index == DATATYPE_ARRAY) {
        return 1;
    }
    return 0;
}


void sys_properties_set_c(MiniJVM *jvm, c8 const *key, c8 const *val) {
    Utf8String *ukey = utf8_create_c(key);
    Utf8String *uval = utf8_create_c(val);
    //this hashtable has a value destroy function , so just keep putting it in
    hashtable_put(jvm->sys_prop, ukey, uval);
}

s32 sys_properties_load(MiniJVM *jvm) {
    jvm->sys_prop = hashtable_create(UNICODE_STR_HASH_FUNC, UNICODE_STR_EQUALS_FUNC);
    hashtable_register_free_functions(jvm->sys_prop,
                                      (HashtableKeyFreeFunc) utf8_destroy,
                                      (HashtableValueFreeFunc) utf8_destroy);
    Utf8String *ustr = NULL;
    Utf8String *prop_name = utf8_create_c("sys.properties");
    ByteBuf *buf = load_file_from_classpath(jvm->boot_classloader, prop_name);
    if (buf) {
        ustr = utf8_create();
        while (bytebuf_available(buf)) {
            c8 ch = (c8) bytebuf_read(buf);
            utf8_insert(ustr, ustr->length, ch);
        }
        bytebuf_destroy(buf);
    }
    utf8_destroy(prop_name);
    //parse
    if (ustr) {
        utf8_replace_c(ustr, "\r\n", "\n");
        utf8_replace_c(ustr, "\r", "\n");
        Utf8String *line = utf8_create();
        while (ustr->length > 0) {
            s32 lineEndAt = utf8_indexof_c(ustr, "\n");
            utf8_clear(line);
            if (lineEndAt >= 0) {
                utf8_append_part(line, ustr, 0, lineEndAt);
                utf8_substring(ustr, lineEndAt + 1, ustr->length);
            } else {
                utf8_append_part(line, ustr, 0, ustr->length);
                utf8_substring(ustr, ustr->length, ustr->length);
            }
            s32 eqAt = utf8_indexof_c(line, "=");
            if (eqAt > 0) {
                Utf8String *key = utf8_create();
                Utf8String *val = utf8_create();
                utf8_append_part(key, line, 0, eqAt);
                utf8_append_part(val, line, eqAt + 1, line->length - (eqAt + 1));
                hashtable_put(jvm->sys_prop, key, val);
            }
        }
        utf8_destroy(line);
        utf8_destroy(ustr);
    }

    sys_properties_set_c(jvm, "path.separator", PATHSEPARATOR);
    //modify os para
#if __JVM_OS_MAC__
    sys_properties_set_c(jvm, "os.name", "Mac OS");
    sys_properties_set_c(jvm, "file.separator", "/");
    sys_properties_set_c(jvm, "line.separator", "\n");
    sys_properties_set_c(jvm, "XstartOnFirstThread", "1");
#elif __JVM_OS_LINUX__
    sys_properties_set_c(jvm, "os.name", "Linux");
    sys_properties_set_c(jvm, "file.separator", "/");
    sys_properties_set_c(jvm, "line.separator", "\n");
#elif __JVM_OS_MINGW__ || __JVM_OS_CYGWIN__ || __JVM_OS_VS__
    sys_properties_set_c(jvm, "os.name", "Windows");
    sys_properties_set_c(jvm, "file.separator", "\\");
    sys_properties_set_c(jvm, "line.separator", "\r\n");
#endif

#if defined(__x86_64__) || defined(__amd64__) || defined(_M_X64)
    sys_properties_set_c(jvm, "os.arch", "x86_64");
#elif defined(__i386__) || defined(__i486__) || defined(__i586__) || defined(__i686__) || defined(_M_IX86)
    sys_properties_set_c(jvm, "os.arch", "i386");
#elif defined(__ia64__)
    sys_properties_set_c(jvm, "os.arch", "ia64");
#elif defined(__arm__)
    sys_properties_set_c(jvm, "os.arch", "arm");
#elif defined(__thumb__)
    sys_properties_set_c(jvm, "os.arch", "thumb");
#elif defined(__mips__)
    sys_properties_set_c(jvm, "os.arch", "mips");
#elif defined(__alpha__)
    sys_properties_set_c(jvm, "os.arch", "alpha");
#else
    sys_properties_set_c(jvm, "os.arch", "unknow");
#endif


    return 0;
}

void sys_properties_dispose(MiniJVM *jvm) {
    hashtable_destroy(jvm->sys_prop);
}

extern FILE *logfile; //defined in d_type.c
void invoke_deepth(Runtime *runtime) {
    vm_share_lock(runtime->jvm);
    s32 i = 0;
    Runtime *r = runtime;
    while (r) {
        i++;
        r = r->parent;
    }
    s32 len = i;

#if _JVM_DEBUG_LOG_TO_FILE
    fprintf(logfile, "%llx", (s64) (intptr_t) thrd_current());
    for (i = 0; i < len; i++) {
        fprintf(logfile, "  ");
    }
#else
    fprintf(stderr, "%llx", (s64) (intptr_t) thrd_current());
    for (i = 0; i < len; i++) {
        fprintf(stderr, "  ");
    }
#endif
    vm_share_unlock(runtime->jvm);
}

//===============================    java 线程  ==================================

s32 jthread_init(MiniJVM *jvm, Instance *jthread) {
    Runtime *runtime = jthread_get_stackframe_value(jvm, jthread);

    runtime->clazz = jthread->mb.clazz;
    runtime->thrd_info->jthread = jthread;
    threadlist_add(runtime);
    return 0;
}

s32 jthread_dispose(Instance *jthread, Runtime *runtime) {
    gc_move_objs_thread_2_gc(runtime);
    threadlist_remove(runtime);
    if (jdwp_client_count(runtime->jvm->jdwpserver)) {
        //jdwpserver might stoped when
        event_on_thread_death(runtime->jvm->jdwpserver, runtime->thrd_info->jthread);
    }
    //destroy
    jthread_set_stackframe_value(runtime->jvm, jthread, NULL);

    return 0;
}

s32 jthread_run(void *para) {
    Runtime *runtime = (Runtime *) para;
    Instance *jthread = runtime->thrd_info->jthread;
    MiniJVM *jvm = runtime->jvm;

#if _JVM_DEBUG_LOG_LEVEL > 1
    s64 startAt = currentTimeMillis();
    jvm_printf("[INFO]thread(pthread %llx) start jthread %llx\n", (s64) (intptr_t) thrd_current(), (s64) (intptr_t) jthread);
#endif
    s32 ret = 0;

    Utf8String *methodName = utf8_create_c("run");
    Utf8String *methodType = utf8_create_c("()V");
    MethodInfo *method = NULL;
    method = find_instance_methodInfo_by_name(jthread, methodName, methodType, runtime);
#if _JVM_DEBUG_LOG_LEVEL > 5
    jvm_printf("therad_loader    %s.%s%s  \n", utf8_cstr(method->_this_class->name),
               utf8_cstr(method->name), utf8_cstr(method->descriptor));
#endif
    //gc_refer_reg(runtime, jthread);//20201019 gust comment it , duplicate reg
    if (jdwp_client_count(jvm->jdwpserver))event_on_thread_start(jvm->jdwpserver, runtime->thrd_info->jthread);
    check_suspend_and_pause(runtime); //check suspend if gc is running
    runtime->thrd_info->thread_status = THREAD_STATUS_RUNNING;
    push_ref(runtime->stack, (__refer) jthread);
    ret = execute_method_impl(method, runtime);
    if (ret == RUNTIME_STATUS_EXCEPTION) {
        print_exception(runtime);
    }

    /* Unified exit cleanup: release every monitor this thread still owns
     * (a Thread.stop() kill unwinds past all monitorexits) on the dying
     * OS thread itself. Idempotent; normal exits reach it with an empty
     * chain. */
    jthread_release_all_owned(runtime);

    //run Thread.exit()
    utf8_clear(methodName);
    utf8_clear(methodType);
    utf8_append_c(methodName, "exit");
    utf8_append_c(methodType, "()V");
    runtime->thrd_info->thread_status = THREAD_STATUS_RUNNING;
    runtime->thrd_info->is_interrupt = 0;
    runtime->thrd_info->is_stop = 0;
    runtime->thrd_info->is_suspend = 0;
    runtime->thrd_info->is_blocking = 0;
    method = find_instance_methodInfo_by_name(jthread, methodName, methodType, runtime);
    push_ref(runtime->stack, (__refer) jthread);
    execute_method_impl(method, runtime);

    runtime->thrd_info->thread_status = THREAD_STATUS_ZOMBIE;
    jthread_assert_no_owned_locks(runtime->thrd_info);

    utf8_destroy(methodName);
    utf8_destroy(methodType);
#if _JVM_DEBUG_LOG_LEVEL > 1
    s64 spent = currentTimeMillis() - startAt;
    jvm_printf("[INFO]thread over %llx , return %d , spent : %lld\n", (s64) (intptr_t) jthread, ret, spent);
#endif
#if __JVM_PRI_ALLOC__

#endif
    thrd_exit(ret);
    return ret;
}

/**
 * the thread finalize, called by gc thread, else the threadlist is
 * @param runtime
 * @return
 */
s32 jthread_run_finalize(Runtime *runtime) {
    if (!runtime)return -1;
    //GC-captured dead thread: report protocol holes instead of unlocking
    //from the wrong (GC) OS thread
    jthread_assert_no_owned_locks(runtime->thrd_info);
    Instance *jthread = runtime->thrd_info->jthread;
    if (jthread) {
        // if the thread status is NEW, then jthread is NULL
        jthread_dispose(jthread, runtime);
    }
    runtime_destroy(runtime);
    return 0;
}

thrd_t jthread_start(Instance *ins, Runtime *parent) {
    //
    Runtime *runtime = jthread_get_stackframe_value(parent->jvm, ins);
    if (!runtime) {
        runtime = runtime_create(parent->jvm);
        runtime->thrd_info->type = THREAD_TYPE_NORMAL;
        jthread_set_stackframe_value(parent->jvm, ins, runtime);
    }
    runtime->thrd_info->thread_status = THREAD_STATUS_RUNNING;
    runtime->thrd_info->jthread = ins;
    runtime->thrd_info->context_classloader = parent->thrd_info->context_classloader; //copy context classloader

    jthread_init(runtime->jvm, ins);
    if (jdwp_is_invoking(runtime->jvm->jdwpserver)) {
        //born during a debugger invoke: the invoke assumes it is the only
        //java executor (locks are skipped), so start parked - jdwp_invoke_end
        //releases threads that appeared while it was running
        jthread_suspend(runtime);
    }
    thrd_create(&runtime->thrd_info->pthread, jthread_run, runtime);
    return runtime->thrd_info->pthread;
}

__refer jthread_get_name_value(MiniJVM *jvm, Instance *ins) {
    c8 *ptr = getInstanceFieldPtr(ins, jvm->shortcut.thread_name);
    return getFieldRefer(ptr);
}

__refer jthread_get_stackframe_value(MiniJVM *jvm, Instance *ins) {
    if (!ins) return NULL;
    c8 *ptr = getInstanceFieldPtr(ins, jvm->shortcut.thread_stackFrame);
    return (__refer) (intptr_t) getFieldLong(ptr);
}

void jthread_set_stackframe_value(MiniJVM *jvm, Instance *ins, __refer val) {
    c8 *ptr = getInstanceFieldPtr(ins, jvm->shortcut.thread_stackFrame);
    setFieldLong(ptr, (s64) (intptr_t) val);
    if (val && !GCFLAG_JTHREAD_GET(ins->mb.gcflag)) {
        //first attach: register in the capturable side list (immix only);
        //later clears keep the flag but pass val=NULL so no re-registration
        GCFLAG_JTHREAD_SET(ins->mb.gcflag);
        gc_side_register_jthread_for_jvm(jvm, ins);
    }
}

s32 jthread_get_daemon_value(Instance *ins, Runtime *runtime) {
    c8 *ptr = getFieldPtr_byName_c(ins, STR_CLASS_JAVA_LANG_THREAD, "daemon", "Z", runtime);
    if (ptr) {
        return getFieldByte(ptr);
    }
    return 0;
}

void jthread_set_daemon_value(Instance *ins, Runtime *runtime, s32 daemon) {
    c8 *ptr = getFieldPtr_byName_c(ins, STR_CLASS_JAVA_LANG_THREAD, "daemon", "Z", runtime);
    if (ptr) {
        setFieldByte(ptr, (s8) daemon);
    }
}

void jthreadlock_create(Runtime *runtime, MemoryBlock *mb) {
    /* lazy object-monitor creation. mtx_timed (non-recursive): the java
     * re-entry lives in recursion_count; timedlock needs the timed flag
     * on this tinycthread build. */
    spin_lock(&runtime->jvm->monitor_create_lock);
    if (!mb->thread_lock) {
        ThreadLock *tl = jvm_calloc(sizeof(ThreadLock));
        if (tl) {
            cnd_init(&tl->thread_cond);
            mtx_init(&tl->mutex_lock, mtx_timed);
            spin_init(&tl->metadata_lock, 0);
            tl->object = mb;
            mb->thread_lock = tl;
        }
    }
    spin_unlock(&runtime->jvm->monitor_create_lock);
}

static ThreadLock *jthreadlock_get_or_create(Runtime *runtime, MemoryBlock *mb) {
    ThreadLock *tl = mb->thread_lock;
    if (!tl) {
        jthreadlock_create(runtime, mb);
        tl = mb->thread_lock;
    }
    return tl; //NULL only on monitor OOM: callers must fail closed
}

void jthreadlock_destroy(MemoryBlock *mb) {
    ThreadLock *tl = mb->thread_lock;
    if (tl) {
        if (tl->owner_thread || tl->recursion_count || tl->enter_waiter_count ||
            tl->wait_waiter_count || tl->owner_prev || tl->owner_next) {
            //root-scan or thread-exit protocol defect: keep it, report it
            jvm_printf("[ERROR] jthreadlock_destroy: active monitor object=%p owner=%p rec=%u ew=%u ww=%u\n",
                       (void *) mb, (void *) tl->owner_thread, tl->recursion_count,
                       tl->enter_waiter_count, tl->wait_waiter_count);
            return;
        }
        thread_lock_dispose(tl);
        jvm_free(tl);
        mb->thread_lock = NULL;
    }
}

//=====================  owner intrusive chain  =========================

static void owned_lock_link(JavaThreadInfo *ti, ThreadLock *lock) {
    lock->owner_prev = NULL;
    lock->owner_next = ti->owned_lock_head;
    if (ti->owned_lock_head) ti->owned_lock_head->owner_prev = lock;
    ti->owned_lock_head = lock;
}

static void owned_lock_unlink(JavaThreadInfo *ti, ThreadLock *lock) {
    if (lock->owner_prev) lock->owner_prev->owner_next = lock->owner_next;
    else if (ti->owned_lock_head == lock) ti->owned_lock_head = lock->owner_next;
    if (lock->owner_next) lock->owner_next->owner_prev = lock->owner_prev;
    lock->owner_prev = NULL;
    lock->owner_next = NULL;
}

//=====================  monitorenter / monitorexit  =====================

s32 jthread_lock(MemoryBlock *mb, Runtime *runtime) {
    //flat OS mutex held once; java re-entry is recursion_count only
    if (mb == NULL)return -1;
    ThreadLock *tl = jthreadlock_get_or_create(runtime, mb);
    if (!tl) {
        return -1; //monitor OOM: fail closed, never run synchronized code unlocked
    }
    JavaThreadInfo *ti = runtime->thrd_info;
    if (tl->owner_thread == ti) {
        //re-entry fast path (owner reads its own writes)
        tl->recursion_count++;
        return 0;
    }
    {
        struct timespec t;
        spin_lock(&ti->lock);
        ti->entering_lock = tl; //root + stop visibility while blocked
        spin_unlock(&ti->lock);
        spin_lock(&tl->metadata_lock);
        tl->enter_waiter_count++;
        spin_unlock(&tl->metadata_lock);
        while (1) {
            // Refresh the deadline before every attempt, including after a GC pause.
            timespec_get(&t, TIME_UTC);
            t.tv_nsec += 2 * NANO_2_MILLS_SCALE;
            if (t.tv_nsec >= 1000000000L) {
                t.tv_nsec -= 1000000000L;
                t.tv_sec += 1;
            }
            if (mtx_timedlock(&tl->mutex_lock, &t) == thrd_success) break;
            check_suspend_and_pause(runtime);
            if (IS_JDWP_ENABLED(runtime)) {
                JavaThreadInfo *owner_snap = tl->owner_thread;
                Runtime *lock_holder = owner_snap ? owner_snap->top_runtime : NULL;
                if (lock_holder && lock_holder != runtime &&
                    lock_holder->thrd_info->suspend_count > 0) {
                    temporarily_resume_for_lock_release(lock_holder, mb);
                }
            }
            if (ti->is_stop) {
                //Thread.stop while blocked on monitorenter: die here
                spin_lock(&tl->metadata_lock);
                tl->enter_waiter_count--;
                spin_unlock(&tl->metadata_lock);
                spin_lock(&ti->lock);
                ti->entering_lock = NULL;
                spin_unlock(&ti->lock);
                return RUNTIME_STATUS_ERROR;
            }
            jthread_yield(runtime);
        }
        spin_lock(&tl->metadata_lock);
        tl->enter_waiter_count--;
        spin_unlock(&tl->metadata_lock);
        spin_lock(&ti->lock);
        ti->entering_lock = NULL;
        spin_unlock(&ti->lock);
    }
    //acquired: publish owner, then link (chain read by GC under STW)
    spin_lock(&tl->metadata_lock);
    tl->owner_thread = ti;
    tl->recursion_count = 1;
    spin_unlock(&tl->metadata_lock);
    owned_lock_link(ti, tl);
    thread_add_held_lock(runtime, mb); //JDWP debug view (phase A)
    return 0;
}

s32 jthread_unlock(MemoryBlock *mb, Runtime *runtime) {
    if (mb == NULL)return -1;
    ThreadLock *tl = mb->thread_lock; //never create on unlock
    if (!tl) return -1;
    JavaThreadInfo *ti = runtime->thrd_info;
    if (tl->owner_thread != ti || tl->recursion_count == 0) {
        if (jdwp_is_ignore_sync(runtime->jvm->jdwpserver, runtime)) {
            //invoke skips monitorenter, so a stray unlock here is expected
            //(e.g. an exception-unwind path releasing a never-taken monitor).
            //Silent no-op instead of the not-owner error.
            return 0;
        }
        jvm_printf("[ERROR]Thread %p trying to unlock a mutex owned by %p\n",
                   (void *) ti, (void *) tl->owner_thread);
        print_runtime_stack(runtime);
        return -1;
    }
    if (tl->recursion_count > 1) {
        tl->recursion_count--;
        return 0;
    }
    //full release: clear chain/owner state FIRST, then the OS mutex, so the
    //next owner never observes stale metadata
    owned_lock_unlink(ti, tl);
    spin_lock(&tl->metadata_lock);
    tl->owner_thread = NULL;
    tl->recursion_count = 0;
    spin_unlock(&tl->metadata_lock);
    s32 ret = mtx_unlock(&tl->mutex_lock);
    if (ret != thrd_success) {
        jvm_printf("[ERROR] unlocking mutex in jthread_unlock. Thread: %llx\n",
                   (s64) (intptr_t) ti->jthread);
        return -1;
    }
    thread_remove_held_lock(runtime, mb); //JDWP debug view (phase A)
    return 0;
}

s32 jthread_notify(MemoryBlock *mb, Runtime *runtime) {
    if (mb == NULL)return -1;
    ThreadLock *tl = mb->thread_lock;
    if (!tl || tl->owner_thread != runtime->thrd_info || tl->recursion_count == 0) {
        return -1; //not owner: IllegalMonitorState
    }
    cnd_signal(&tl->thread_cond);
    return 0;
}

s32 jthread_notifyAll(MemoryBlock *mb, Runtime *runtime) {
    if (mb == NULL)return -1;
    ThreadLock *tl = mb->thread_lock;
    if (!tl || tl->owner_thread != runtime->thrd_info || tl->recursion_count == 0) {
        return -1; //not owner: IllegalMonitorState
    }
    cnd_broadcast(&tl->thread_cond);
    return 0;
}

s32 jthread_interrupt(Runtime *rt_thread) {
    if (rt_thread) {
        rt_thread->thrd_info->is_interrupt = 1;

        if (rt_thread->thrd_info->thread_status == THREAD_STATUS_WAIT) {
            jthread_wakeup(rt_thread);
        }
        return 0;
    }
    return -1;
}

s32 jthread_yield(Runtime *runtime) {
    thrd_yield();
    return 0;
}

s32 jthread_suspend(Runtime *runtime) {
    spin_lock(&runtime->thrd_info->lock);
    runtime->thrd_info->suspend_count++;
    //jvm_printf("[DEBUG] Thread %llx is suspended  %d\n", (s64) (intptr_t) (runtime->thrd_info->jthread), runtime->thrd_info->suspend_count);
    spin_unlock(&runtime->thrd_info->lock);
    return 0;
}

void jthread_block_enter(Runtime *runtime) {
    runtime->thrd_info->is_blocking = 1;
}

void jthread_block_exit(Runtime *runtime) {
    runtime->thrd_info->is_blocking = 0;
    check_suspend_and_pause(runtime);
}

s32 jthread_resume(Runtime *runtime) {
    spin_lock(&runtime->thrd_info->lock);
    if (runtime->thrd_info->suspend_count > 0) {
        runtime->thrd_info->suspend_count--;
        //wake parked threads immediately; the 100ms poll in
        //check_suspend_and_pause is only a fallback. Without the
        //notify a JDWP resume races the debugger's next command.
        vm_share_notifyall(runtime->jvm);
    }
    //jvm_printf("[DEBUG] Thread %llx is resumed    %d\n", (s64) (intptr_t) (runtime->thrd_info->jthread), runtime->thrd_info->suspend_count);
    spin_unlock(&runtime->thrd_info->lock);
    return 0;
}

s32 jthread_waitTime(MemoryBlock *mb, Runtime *runtime, s64 waitms) {
    if (mb == NULL)return -1;
    ThreadLock *tl = mb->thread_lock;
    JavaThreadInfo *ti = runtime->thrd_info;
    if (!tl) {
        /* miniJVM semantic: synchronized METHODS are lock-free without a
         * JDWP session (jdwp_is_ignore_sync), so Thread.join()'s
         * synchronized wait() legitimately arrives at a never-locked
         * object. Adopt the monitor implicitly instead of failing. */
        tl = jthreadlock_get_or_create(runtime, mb);
        if (!tl) return -1;
    }
    if (tl->owner_thread != ti || tl->recursion_count == 0) {
        if (tl->owner_thread == NULL && tl->wait_waiter_count + tl->enter_waiter_count == 0) {
            /* free monitor adopted by a lock-free synchronized-method waiter */
            spin_lock(&tl->metadata_lock);
            tl->owner_thread = ti;
            tl->recursion_count = 1;
            spin_unlock(&tl->metadata_lock);
            owned_lock_link(ti, tl);
        } else {
            return -1; //genuinely owned by someone else: IllegalMonitorState
        }
    }
    u32 saved_recursion = tl->recursion_count;
    //fully release the java monitor for the park
    owned_lock_unlink(ti, tl);
    spin_lock(&tl->metadata_lock);
    tl->owner_thread = NULL;
    tl->recursion_count = 0;
    tl->wait_waiter_count++;
    spin_unlock(&tl->metadata_lock);
    //publish the park target before leaving the owned chain (GC root continuity)
    spin_lock(&ti->lock);
    ti->waiting_lock = tl;
    spin_unlock(&ti->lock);
    if (IS_JDWP_ENABLED(runtime) && saved_recursion > 0) {
        arraylist_remove(ti->held_locks, mb);
        if (ti->held_locks->length == 0) {
            ti->curThreadLock = NULL;
        }
    }
    jthread_block_enter(runtime);
    u8 thread_status = ti->thread_status;
    ti->thread_status = THREAD_STATUS_WAIT;
    {
        /* A stop/interrupt broadcaster can observe waiting_lock before this
         * thread has actually entered cnd_wait.  Its bounded mutex acquire
         * may then time out and the signal would be lost, leaving wait(0)
         * parked forever during VM shutdown.  Use short timed slices and
         * re-check the persistent stop/interrupt predicates.  A real notify
         * still returns thrd_success immediately (spurious wakeups are legal
         * for Object.wait). */
        s64 deadline = waitms > 0 ? currentTimeMillis() + waitms : 0;
        while (!ti->is_stop && !ti->is_interrupt) {
            s64 now = currentTimeMillis();
            if (deadline && now >= deadline) break;
            s64 slice_deadline = now + 100;
            if (deadline && slice_deadline > deadline) slice_deadline = deadline;
            struct timespec t;
            t.tv_sec = (time_t) (slice_deadline / 1000);
            t.tv_nsec = (long) ((slice_deadline % 1000) * 1000000);
            s32 wait_result = cnd_timedwait(&tl->thread_cond, &tl->mutex_lock, &t);
            if (wait_result != thrd_timedout) break;
            /* Object.wait is allowed to return spuriously.  Return after a
             * slice so Java-level condition loops (including every join
             * overload) can observe state changes even though miniJVM does
             * not yet issue a VM-generated notifyAll on thread termination. */
            break;
        }
    }
    ti->thread_status = thread_status;
    //cnd_wait returned holding the flat mutex: restore the monitor fully
    spin_lock(&tl->metadata_lock);
    tl->owner_thread = ti;
    tl->recursion_count = saved_recursion;
    tl->wait_waiter_count--;
    spin_unlock(&tl->metadata_lock);
    owned_lock_link(ti, tl);
    spin_lock(&ti->lock);
    ti->waiting_lock = NULL;
    spin_unlock(&ti->lock);
    if (IS_JDWP_ENABLED(runtime) && saved_recursion > 0) {
        arraylist_push_back(ti->held_locks, mb);
        if (ti->held_locks->length == 1) {
            ti->curThreadLock = mb;
        }
    }
    jthread_block_exit(runtime);
    /* Thread.stop() while parked: die now instead of waiting for the next
     * java method entry (a catch-everything loop parked here may never
     * call one). The monitor just reacquired is released by the unified
     * thread-exit cleanup. */
    if (ti->is_stop) {
        return RUNTIME_STATUS_ERROR;
    }
    return check_throw_interruptexception(runtime);
}

//if the thread is waiting , wake it up
//stop/interrupt helper: wake a thread parked in Object.wait(). Takes the
//monitor mutex (bounded) before broadcasting so the signal cannot land in
//the gap before the waiter parks; never blocks holding thread_list locks.
s32 jthread_wakeup(Runtime *runtime) {
    ThreadLock *tl;
    spin_lock(&runtime->thrd_info->lock);
    tl = runtime->thrd_info->waiting_lock;
    spin_unlock(&runtime->thrd_info->lock);
    if (!tl) {
        return 0;
    }
    {
        struct timespec t;
        timespec_get(&t, TIME_UTC);
        t.tv_nsec += 20 * NANO_2_MILLS_SCALE;
        if (t.tv_nsec >= 1000000000L) {
            t.tv_nsec -= 1000000000L;
            t.tv_sec += 1;
        }
        if (mtx_timedlock(&tl->mutex_lock, &t) == thrd_success) {
            cnd_broadcast(&tl->thread_cond);
            mtx_unlock(&tl->mutex_lock);
        }
    }
    return 0;
}

/* Unified thread-exit cleanup: release EVERY monitor this thread still
 * owns (a Thread.stop() kill unwinds past all monitorexits). Runs on the
 * dying OS thread itself; idempotent. */
void jthread_release_all_owned(Runtime *runtime) {
    JavaThreadInfo *ti = runtime->thrd_info;
    ThreadLock *tl = ti->owned_lock_head;
    while (tl) {
        ThreadLock *next = tl->owner_next;
        owned_lock_unlink(ti, tl);
        spin_lock(&tl->metadata_lock);
        tl->owner_thread = NULL;
        tl->recursion_count = 0;
        spin_unlock(&tl->metadata_lock);
        mtx_unlock(&tl->mutex_lock); //flat mutex: one unlock regardless of depth
        cnd_broadcast(&tl->thread_cond); //wake enter/exit competitors
        tl = next;
    }
    ti->owned_lock_head = NULL;
}

/* teardown assertion: report protocol holes instead of cross-thread unlock */
void jthread_assert_no_owned_locks(JavaThreadInfo *ti) {
    if (ti->owned_lock_head) {
        jvm_printf("[ERROR] thread exit with owned monitors (head=%p)\n",
                   (void *) ti->owned_lock_head);
    }
    if (ti->waiting_lock) {
        jvm_printf("[ERROR] thread exit marked waiting (lock=%p)\n",
                   (void *) ti->waiting_lock);
    }
    if (ti->entering_lock) {
        jvm_printf("[ERROR] thread exit marked entering (lock=%p)\n",
                   (void *) ti->entering_lock);
    }
}

s32 jthread_sleep(Runtime *runtime, s64 ms) {
    static const s64 PERIOD = 500;
    jthread_block_enter(runtime);
    u8 thread_status = runtime->thrd_info->thread_status;
    runtime->thrd_info->thread_status = THREAD_STATUS_SLEEPING;
    if (ms < PERIOD) {
        threadSleep(ms);
    } else {
        s64 sleeped = 0, remain;
        while (sleeped < ms) {
            remain = ms - sleeped;
            threadSleep(remain < PERIOD ? remain : PERIOD);
            sleeped += PERIOD;
            if (runtime->thrd_info->is_interrupt || runtime->thrd_info->is_stop) {
                break;
            }
        }
    }
    runtime->thrd_info->thread_status = thread_status;
    jthread_block_exit(runtime);
    return check_throw_interruptexception(runtime);;
}

s32 check_throw_interruptexception(Runtime *runtime) {
    if (!runtime->thrd_info->is_interrupt) {
        return RUNTIME_STATUS_NORMAL;
    }
    runtime->thrd_info->is_interrupt = 0;
    Instance *exception = exception_create(JVM_EXCEPTION_INTERRUPTED, runtime);
    push_ref(runtime->stack, (__refer) exception);
    return RUNTIME_STATUS_EXCEPTION;
}

s32 check_suspend_and_pause(Runtime *runtime) {
    JavaThreadInfo *threadInfo = runtime->thrd_info;
    MiniJVM *jvm = runtime->jvm;
    if (threadInfo->suspend_count && !threadInfo->no_pause) {
        // 使用精确的锁列表检查线程是否持有任何锁（仅JDWP模式）
        // 只有当线程持有pending_release_lock时才延迟挂起（精确的锁冲突检测）
        if (IS_JDWP_ENABLED(runtime) && threadInfo->pending_release_lock != NULL) {
            // 检查当前线程是否在单步调试模式
            u8 is_stepping = threadInfo->jdwp_step && threadInfo->jdwp_step->active;

            // 只有在单步模式下才启用防死锁机制
            if (is_stepping && thread_owns_lock(runtime, threadInfo->pending_release_lock)) {
                // jvm_printf("[DEBUG] Thread %llx in stepping mode, defer suspension for lock %llx\n",
                //           (s64) (intptr_t) threadInfo->jthread,
                //           (s64) (intptr_t) threadInfo->pending_release_lock);
                return 0; // 单步模式：返回而不挂起
            } else if (!is_stepping) {
                // 断点模式：清除pending_release_lock标记，强制挂起
                threadInfo->pending_release_lock = NULL;
                // jvm_printf("[DEBUG] Thread %llx in breakpoint mode, force suspension\n",
                //           (s64) (intptr_t) threadInfo->jthread);
            } else {
                // 如果不再持有待释放的锁，清除标记
                threadInfo->pending_release_lock = NULL;
            }
        }

        vm_share_lock(jvm);
        threadInfo->is_suspend = 1;
        vm_share_notifyall(jvm);
        //no_pause/is_stop (System.exit / JDWP VirtualMachine.Exit) must be
        //able to release threads that are ALREADY parked here: no_pause only
        //guards entry, so without this check a debugger-suspended VM never
        //dies - the parked thread re-parks forever and the interpreter's
        //is_stop unwind never gets a chance to run
        while (threadInfo->suspend_count && !threadInfo->no_pause && !threadInfo->is_stop) {
            vm_share_timedwait(jvm, 100);
            //            thrd_yield();
        }
        threadInfo->is_suspend = 0;
        //jvm_printf(".");
        vm_share_unlock(jvm);
    }
    return 0;
}

//===============================    实例化数组  ==================================
Instance *jarray_create_by_class(Runtime *runtime, s32 count, JClass *clazz) {
    if (count < 0 || !clazz)return NULL;
    s32 typeIdx = clazz->mb.arr_type_index;
    s32 insSize = jvm_array_alloc_size(typeIdx, count);
    if (insSize < 0) return NULL;
    Instance *arr = gc_obj_alloc(runtime, insSize, IMMIX_OBJECT_ARRAY);
    if (!arr) return NULL;
    arr->mb.heap_size = insSize;
    arr->mb.type = MEM_TYPE_ARR;
    arr->mb.clazz = clazz;
    arr->mb.arr_type_index = typeIdx;
    jarray_set_length(arr, count); //reserved stays 0, body is inline
    if (!gc_backend_is_immix(runtime->jvm)) {
        //immix: enumerated by block bitmap
        gc_obj_reg(runtime, arr);
    }
    //    jvm_printf("%s\n", utf8_cstr(clazz->name));
    //    if(utf8_equals_c(clazz->name,"[Lorg/mini/util/StringFormatImpl$FmtCmpnt;")){
    //        int debug = 1;
    //    }
    return arr;
}

Instance *jarray_create_by_type_index(Runtime *runtime, s32 count, s32 typeIdx) {
    JClass *clazz = NULL;
    clazz = array_class_get_by_index(runtime, typeIdx);
    Instance *arr = jarray_create_by_class(runtime, count, clazz);
    return arr;
}

Instance *jarray_create_by_type_name(Runtime *runtime, s32 count, Utf8String *name, Instance *jloader) {
    JClass *clazz = NULL;
    clazz = array_class_get_by_name(runtime, jloader, name);
    Instance *arr = jarray_create_by_class(runtime, count, clazz);
    return arr;
}


s32 jarray_destroy(Instance *arr) {
    if (arr && arr->mb.type == MEM_TYPE_ARR) {
        jthreadlock_destroy(&arr->mb);
        arr->mb.thread_lock = NULL;
        jarray_set_length(arr, -1);
        //malloc backend only: Immix arrays are reclaimed by the block sweep,
        //memoryblock_destroy is never called for them on that backend.
        jvm_free(arr); // 确保释放数组内存
    }
    return 0;
}

/**
 * create multi array
 * @param dim arrdim
 * @param pdesc desc
 * @return ins
 */
Instance *jarray_multi_create(Runtime *runtime, s32 *dim, s32 dim_size, Utf8String *pdesc, s32 deep) {
    if (!dim || deep < 0 || deep >= dim_size) return NULL;
    s32 len = dim[dim_size - 1 - deep];
    if (len < 0) {
        return NULL;
    }
    JClass *cl = array_class_create_get(runtime, runtime->clazz->jloader, pdesc);
    Instance *arr = jarray_create_by_class(runtime, len, cl);
    if (!arr) return NULL;
    if (instance_hold_to_thread(arr, runtime) != 0) return NULL;
    Utf8String *desc = utf8_create_part(pdesc, 1, pdesc->length - 1);
    if (!desc) {
        instance_release_from_thread(arr, runtime);
        return NULL;
    }

    c8 ch = utf8_char_at(desc, 0);
#if _JVM_DEBUG_LOG_LEVEL > 5
    jvm_printf("multi arr deep :%d  type(%c) arr[%x] size:%d\n", deep, ch, arr, len);
#endif
    if (ch == '[' && deep + 1 < dim_size) {
        s32 i;
        s64 val;
        for (i = 0; i < len; i++) {
            Instance *elem = jarray_multi_create(runtime, dim, dim_size, desc, deep + 1);
            if (!elem) {
                utf8_destroy(desc);
                instance_release_from_thread(arr, runtime);
                return NULL;
            }
            val = (intptr_t) elem;
            jarray_set_field(arr, i, val);
        }
    }
    utf8_destroy(desc);
    instance_release_from_thread(arr, runtime);
    return arr;
}


void jarray_set_field(Instance *arr, s32 index, s64 val) {
    s32 idx = arr->mb.arr_type_index;
    s32 bytes = DATA_TYPE_BYTES[idx];
    if (isDataReferByIndex(idx)) {
        setFieldRefer((c8 *) ((__refer *) jarray_body(arr) + index), (__refer) (intptr_t) val);
    } else {
        switch (bytes) {
            case 1:
                setFieldByte((c8 *) (jarray_body(arr) + index), (s8) val);
                break;
            case 2:
                setFieldShort((c8 *) ((s16 *) jarray_body(arr) + index), (s16) val);
                break;
            case 4:
                setFieldInt((c8 *) ((s32 *) jarray_body(arr) + index), (s32) val);
                break;
            case 8:
                setFieldLong((c8 *) ((s64 *) jarray_body(arr) + index), val);
                break;
        }
    }
}

s64 jarray_get_field(Instance *arr, s32 index) {
    s32 idx = arr->mb.arr_type_index;
    s32 bytes = DATA_TYPE_BYTES[idx];
    s64 val = 0;
    if (isDataReferByIndex(idx)) {
        val = (intptr_t) getFieldRefer((c8 *) ((__refer *) jarray_body(arr) + index));
    } else {
        switch (bytes) {
            case 1:
                val = getFieldByte(jarray_body(arr) + index);
                break;
            case 2:
                if (idx == DATATYPE_JCHAR) {
                    val = (u16) getFieldShort((c8 *) ((u16 *) jarray_body(arr) + index));
                } else
                    val = getFieldShort((c8 *) ((s16 *) jarray_body(arr) + index));
                break;
            case 4:
                val = getFieldInt((c8 *) ((s32 *) jarray_body(arr) + index));
                break;
            case 8:
                val = getFieldLong((c8 *) ((s64 *) jarray_body(arr) + index));
                break;
        }
    }
    return val;
}

//===============================    实例化对象  ==================================

Instance *instance_create(Runtime *runtime, JClass *clazz) {
    s32 insSize = jvm_instance_alloc_size(clazz);
    if (insSize < 0) return NULL;
    Instance *ins = gc_obj_alloc(runtime, insSize, IMMIX_OBJECT_INSTANCE);
    if (!ins) return NULL;
    ins->mb.type = MEM_TYPE_INS;
    ins->mb.clazz = clazz;
    ins->mb.heap_size = insSize;
    if (clazz->is_jcloader) {
        GCFLAG_JLOADER_SET(ins->mb.gcflag);
    } else if (clazz->is_weakref) {
        GCFLAG_WEAKREFERENCE_SET(ins->mb.gcflag);
    }
    //    jvm_printf("%s\n", utf8_cstr(clazz->name));
    //    if (utf8_equals_c(clazz->name, "java/lang/String")) {
    //        s32 debug = 1;
    //    }
    if (!gc_backend_is_immix(runtime->jvm)) {
        //immix: enumerated by block bitmap
        gc_obj_reg(runtime, ins);
    } else {
        gc_side_register_instance(runtime, ins); //weak/finalizable/loader side lists
    }
    return ins;
}

void instance_init(Instance *ins, Runtime *runtime) {
    instance_init_with_para(ins, runtime, "()V", NULL);
}

void instance_init_with_para(Instance *ins, Runtime *runtime, c8 *methodtype, RuntimeStack *para) {
    if (ins) {
        Utf8String *methodName = utf8_create_c("<init>");
        Utf8String *methodType = utf8_create_c(methodtype);
        MethodInfo *mi = find_methodInfo_by_name(ins->mb.clazz->name, methodName, methodType, ins->mb.clazz->jloader,
                                                 runtime);
        push_ref(runtime->stack, (__refer) ins);
        if (para) {
            s32 i;
            for (i = 0; i < stack_size(para); i++) {
                StackEntry entry;
                peek_entry(para->store + i, &entry);
                push_entry(runtime->stack, &entry);
            }
        }
        s32 ret = execute_method_impl(mi, runtime);
        if (ret == RUNTIME_STATUS_EXCEPTION) {
            print_exception(runtime);
        }
        utf8_destroy(methodName);
        utf8_destroy(methodType);
    }
}

void instance_finalize(Instance *ins, Runtime *runtime) {
    if (ins) {
        MethodInfo *mi = ins->mb.clazz->finalizeMethod;
        if (mi) {
            push_ref(runtime->stack, ins);
            s32 ret = execute_method_impl(mi, runtime);
            if (ret == RUNTIME_STATUS_EXCEPTION) {
                print_exception(runtime);
            }
        }
    }
}

void instance_of_reference_enqueue(Instance *ins, Runtime *runtime) {
    if (ins) {
        MethodInfo *mi = runtime->jvm->shortcut.reference_vmEnqueneReference;
        if (mi) {
            push_ref(runtime->stack, ins);
            s32 ret = execute_method_impl(mi, runtime);
            if (ret == RUNTIME_STATUS_EXCEPTION) {
                print_exception(runtime);
            }
        }
    }
}

void instance_clear_refer(Instance *ins) {
    s32 i;
    JClass *clazz = ins->mb.clazz;
    while (clazz) {
        FieldPool *fp = &clazz->fieldPool;
        for (i = 0; i < fp->field_used; i++) {
            FieldInfo *fi = &fp->field[i];
            if ((fi->access_flags & ACC_STATIC) == 0 && fi->isrefer) {
                c8 *ptr = getInstanceFieldPtr(ins, fi);
                if (ptr) {
                    setFieldRefer(ptr, NULL);
                }
            }
        }
        clazz = getSuperClass(clazz);
    }
}

s32 instance_destroy(Instance *ins) {
    jthreadlock_destroy(&ins->mb);
    //malloc backend only: Immix instances are reclaimed by the block sweep.
    jvm_free(ins); // 确保释放实例内存
    return 0;
}

/**
 * for java string instance copy
 * deepth copy instance
 * deepth copy array
 *
 * @param src  source instance
 * @return  instance
 */
Instance *instance_copy(Runtime *runtime, Instance *src, s32 deep_copy) {
    s32 insSize;
    if (src->mb.type == MEM_TYPE_INS) {
        insSize = jvm_instance_alloc_size(src->mb.clazz);
    } else if (src->mb.type == MEM_TYPE_ARR) {
        insSize = jvm_array_alloc_size(src->mb.arr_type_index, jarray_length(src));
    } else {
        return NULL;
    }
    if (insSize < 0) return NULL;
    s32 headerSize = src->mb.type == MEM_TYPE_ARR ? JVM_ARRAY_HEADER_SIZE : JVM_INSTANCE_HEADER_SIZE;
    Instance *dst = gc_obj_alloc(runtime, insSize,
                                 src->mb.type == MEM_TYPE_ARR
                                     ? IMMIX_OBJECT_ARRAY
                                     : IMMIX_OBJECT_INSTANCE);
    if (!dst) return NULL;
    memcpy(dst, src, headerSize); //arrays copy length+reserved with the header
    dst->mb.thread_lock = NULL;
    dst->mb.gcflag = src->mb.gcflag;
    GCFLAG_REG_CLEAR(dst->mb.gcflag);
    GCFLAG_FINALIZED_CLEAR(dst->mb.gcflag);
    dst->mb.garbage_mark = 0;
    dst->mb.heap_size = insSize;
    if (src->mb.type == MEM_TYPE_INS) {
        JClass *clazz = src->mb.clazz;
        s32 fileds_len = clazz->field_instance_len;
        if (fileds_len) {
            memcpy(instance_fields(dst), instance_fields(src), fileds_len);
            if (deep_copy) {
                s32 i, len;
                while (clazz) {
                    FieldPool *fp = &clazz->fieldPool;
                    for (i = 0, len = fp->field_used; i < len; i++) {
                        FieldInfo *fi = &fp->field[i];
                        if ((fi->access_flags & ACC_STATIC) == 0 && fi->isrefer) {
                            c8 *ptr = getInstanceFieldPtr(src, fi);
                            Instance *ins = (Instance *) getFieldRefer(ptr);
                            if (ins) {
                                Instance *new_ins = instance_copy(runtime, ins, deep_copy);
                                ptr = getInstanceFieldPtr(dst, fi);
                                setFieldRefer(ptr, new_ins);
                            }
                        }
                    }
                    clazz = getSuperClass(clazz);
                }
            }
        }
    } else if (src->mb.type == MEM_TYPE_ARR) {
        s32 size = jarray_length(src) * DATA_TYPE_BYTES[src->mb.arr_type_index];
        if (isDataReferByIndex(src->mb.arr_type_index) && deep_copy) {
            s32 i;
            s64 val;
            for (i = 0; i < jarray_length(dst); i++) {
                val = jarray_get_field(src, i);
                if (val) {
                    val = (intptr_t) instance_copy(runtime, (Instance *) getFieldRefer((__refer) (intptr_t) val),
                                                   deep_copy);
                    jarray_set_field(dst, i, val);
                }
            }
        } else {
            memcpy(jarray_body(dst), jarray_body(src), size);
        }
    }
    if (!gc_backend_is_immix(runtime->jvm)) {
        //immix: enumerated by block bitmap
        gc_obj_reg(runtime, dst);
    }
    return dst;
}

//===============================    实例化 java.lang.Class  ==================================
/**
 *
 * 每个java 类有一个 java.lang.Class 的实例, 用于承载对相关java类的操作
 *
 * every java Class have a instance of java.lang.Class
 *
 * @param runtime
 * @param clazz
 * @return
 */

Instance *insOfJavaLangClass_create_get(Runtime *runtime, JClass *clazz) {
    JClass *java_lang_class = classes_load_get_with_clinit_c(NULL, STR_CLASS_JAVA_LANG_CLASS, runtime);
    if (java_lang_class) {
        if (clazz->ins_class) {
            return clazz->ins_class;
        } else {
            Instance *ins = instance_create(runtime, java_lang_class);
            instance_init(ins, runtime);
            clazz->ins_class = ins;
            setFieldRefer(getInstanceFieldPtr(ins, runtime->jvm->shortcut.class_classLoader), clazz->jloader);
            insOfJavaLangClass_set_classHandle(runtime, ins, clazz);
            return ins;
        }
    }
    return NULL;
}


JClass *insOfJavaLangClass_get_classHandle(Runtime *runtime, Instance *insOfJavaLangClass) {
    if (!insOfJavaLangClass) return NULL;
    return (JClass *) (intptr_t) getFieldLong(
        getInstanceFieldPtr(insOfJavaLangClass, runtime->jvm->shortcut.class_classHandle));
}

void insOfJavaLangClass_set_classHandle(Runtime *runtime, Instance *insOfJavaLangClass, JClass *handle) {
    setFieldLong(getInstanceFieldPtr(insOfJavaLangClass, runtime->jvm->shortcut.class_classHandle),
                 (s64) (intptr_t) handle);
}

//===============================    实例化字符串  ==================================
Instance *jstring_create(Utf8String *src, Runtime *runtime) {
    if (!src)return NULL;
    JClass *jstr_clazz = classes_load_get_with_clinit_c(NULL, STR_CLASS_JAVA_LANG_STRING, runtime);
    Instance *jstring = instance_create(runtime, jstr_clazz);
    Instance *arr;
    s32 len;
    s32 decoded_len;
    c8 *value_ptr;

    if (!jstring) return NULL;
    if (instance_hold_to_thread(jstring, runtime) != 0) return NULL; //hold for no gc

    /* String.<init>() used to allocate char[DEFAULT_CAP], after which this
     * function allocated a native UTF-16 buffer and sometimes another Java
     * char[]. Count first, allocate the exact Java array, then decode into it
     * directly. Object.<init>() has no state to establish and String fields
     * are already zeroed by instance_create(). */
    len = utf8_2_unicode(src, NULL, 0);
    if (len < 0) {
        instance_release_from_thread(jstring, runtime);
        return NULL;
    }
    arr = jarray_create_by_type_index(runtime, len, DATATYPE_JCHAR);
    if (!arr) {
        instance_release_from_thread(jstring, runtime);
        return NULL;
    }
    value_ptr = jstring_get_value_ptr(jstring, runtime);
    setFieldRefer(value_ptr, (__refer) arr);
    decoded_len = utf8_2_unicode(src, (u16 *) jarray_body(arr), len);
    if (decoded_len != len) {
        instance_release_from_thread(jstring, runtime);
        return NULL;
    }
    jstring_set_offset(jstring, 0, runtime);
    jstring_set_count(jstring, len, runtime);
    instance_release_from_thread(jstring, runtime);
    return jstring;
}

s32 jarray_reference_store_check(Instance *arr, Instance *value) {
    if (!arr || arr->mb.type != MEM_TYPE_ARR || !isDataReferByIndex(arr->mb.arr_type_index)) {
        return 0;
    }
    if (!value) return 1;
    return assignable_from(arr->mb.clazz->component_class, value->mb.clazz) ? 1 : 0;
}

s32 jvm_float_to_int(f32 value) {
    if (isnan(value)) return 0;
    if (value >= (f32) INT_MAX) return INT_MAX;
    if (value <= (f32) INT_MIN) return INT_MIN;
    return (s32) value;
}

s32 jvm_double_to_int(f64 value) {
    if (isnan(value)) return 0;
    if (value >= (f64) INT_MAX) return INT_MAX;
    if (value <= (f64) INT_MIN) return INT_MIN;
    return (s32) value;
}

s64 jvm_float_to_long(f32 value) {
    if (isnan(value)) return 0;
    if (value >= (f32) LLONG_MAX) return LLONG_MAX;
    if (value <= (f32) LLONG_MIN) return LLONG_MIN;
    return (s64) value;
}

s64 jvm_double_to_long(f64 value) {
    if (isnan(value)) return 0;
    if (value >= (f64) LLONG_MAX) return LLONG_MAX;
    if (value <= (f64) LLONG_MIN) return LLONG_MIN;
    return (s64) value;
}

Instance *jstring_create_cstr(c8 const *cstr, Runtime *runtime) {
    if (!cstr)return NULL;
    Utf8String *ustr = utf8_create_part_c(cstr, 0, strlen(cstr));
    Instance *jstr = jstring_create(ustr, runtime);
    utf8_destroy(ustr);
    return jstr;
}

s32 jstring_get_count(Instance *jstr, Runtime *runtime) {
    return getFieldInt(getInstanceFieldPtr(jstr, runtime->jvm->shortcut.string_count));
}

void jstring_set_count(Instance *jstr, s32 count, Runtime *runtime) {
    setFieldInt(getInstanceFieldPtr(jstr, runtime->jvm->shortcut.string_count), count);
}

s32 jstring_get_offset(Instance *jstr, Runtime *runtime) {
    return getFieldInt(getInstanceFieldPtr(jstr, runtime->jvm->shortcut.string_offset));
}

void jstring_set_offset(Instance *jstr, s32 offset, Runtime *runtime) {
    setFieldInt(getInstanceFieldPtr(jstr, runtime->jvm->shortcut.string_offset), offset);
}

c8 *jstring_get_value_ptr(Instance *jstr, Runtime *runtime) {
    return getInstanceFieldPtr(jstr, runtime->jvm->shortcut.string_value);
}

Instance *jstring_get_value_array(Instance *jstr, Runtime *runtime) {
    c8 *fieldPtr = jstring_get_value_ptr(jstr, runtime);
    Instance *arr = (Instance *) getFieldRefer(fieldPtr);
    return arr;
}

u16 jstring_char_at(Instance *jstr, s32 index, Runtime *runtime) {
    Instance *ptr = jstring_get_value_array(jstr, runtime);
    s32 offset = jstring_get_offset(jstr, runtime);
    s32 count = jstring_get_count(jstr, runtime);
    if (index >= count) {
        return -1;
    }
    if (ptr && jarray_length(ptr) > 0) {
        u16 *jchar_arr = (u16 *) jarray_body(ptr);
        return jchar_arr[offset + index];
    }
    return -1;
}


s32 jstring_index_of(Instance *jstr, u16 ch, s32 startAt, Runtime *runtime) {
    c8 *fieldPtr = jstring_get_value_ptr(jstr, runtime);
    Instance *ptr = (Instance *) getFieldRefer(fieldPtr); //c8[]数组实例
    if (ptr && jarray_length(ptr) > 0 && startAt >= 0) {
        u16 *jchar_arr = (u16 *) jarray_body(ptr);
        s32 count = jstring_get_count(jstr, runtime);
        s32 offset = jstring_get_offset(jstr, runtime);
        s32 i;
        for (i = startAt; i < count; i++) {
            if (jchar_arr[i + offset] == ch) {
                return i;
            }
        }
    }
    return -1;
}

s32 jstring_equals(Instance *jstr1, Instance *jstr2, Runtime *runtime) {
    if (!jstr1 && !jstr2) {
        //两个都是null
        return 1;
    } else if (!jstr1) {
        return 0;
    } else if (!jstr2) {
        return 0;
    }
    Instance *arr1 = jstring_get_value_array(jstr1, runtime); //取得 c8[] value
    Instance *arr2 = jstring_get_value_array(jstr2, runtime); //取得 c8[] value
    s32 count1 = 0, offset1 = 0, count2 = 0, offset2 = 0;
    //0长度字符串可能value[] 是空值，也可能不是空值但count是0
    if (arr1) {
        count1 = jstring_get_count(jstr1, runtime);
        offset1 = jstring_get_offset(jstr1, runtime);
    }
    if (arr2) {
        count2 = jstring_get_count(jstr2, runtime);
        offset2 = jstring_get_offset(jstr2, runtime);
    }
    if (count1 != count2) {
        return 0;
    } else if (count1 == 0 && count2 == 0) {
        return 1;
    }
    if (arr1 && arr2 && jarray_length(arr1) > 0 && jarray_length(arr2) > 0) {
        u16 *jchar_arr1 = (u16 *) jarray_body(arr1);
        u16 *jchar_arr2 = (u16 *) jarray_body(arr2);
        s32 i;
        for (i = 0; i < count1; i++) {
            if (jchar_arr1[i + offset1] != jchar_arr2[i + offset2]) {
                return 0;
            }
        }
        return 1;
    }
    return 0;
}

s32 jstring_2_utf8(Instance *jstr, Utf8String *utf8, Runtime *runtime) {
    if (!jstr)return 0;
    Instance *arr = jstring_get_value_array(jstr, runtime);
    if (arr) {
        s32 count = jstring_get_count(jstr, runtime);
        s32 offset = jstring_get_offset(jstr, runtime);
        u16 *arrbody = (u16 *) jarray_body(arr);
        if (jarray_length(arr) > 0)unicode_2_utf8(&arrbody[offset], utf8, count);
    }
    return 0;
}

//===============================    例外  ==================================

Instance *exception_create(s32 exception_type, Runtime *runtime) {
#if _JVM_DEBUG_LOG_LEVEL > 5
    jvm_printf("create exception : %s\n", STRS_CLASS_EXCEPTION[exception_type]);
#endif
    if (exception_type == JVM_ERROR_OUTOFMEMORY && runtime->jvm->out_of_memory_error) {
        return runtime->jvm->out_of_memory_error;
    }
    Utf8String *clsName = utf8_create_c(STRS_CLASS_EXCEPTION[exception_type]);
    JClass *clazz = classes_load_get_with_clinit(NULL, clsName, runtime);
    utf8_destroy(clsName);

    if (!clazz) return NULL;
    Instance *ins = instance_create(runtime, clazz);
    if (!ins) return NULL;
    if (instance_hold_to_thread(ins, runtime) != 0) return NULL;
    instance_init(ins, runtime);
    instance_release_from_thread(ins, runtime);
    return ins;
}

Instance *exception_create_dispatch(s32 exception_type, Runtime *runtime) {
    JClass *clazz = classes_load_get_with_clinit_c(NULL, STRS_CLASS_EXCEPTION[exception_type], runtime);
    if (clazz) {
        Instance *exception = instance_create(runtime, clazz);
        if (exception && instance_hold_to_thread(exception, runtime) == 0) {
            MethodInfo *ctor = find_methodInfo_by_name_c(STRS_CLASS_EXCEPTION[exception_type],
                                                         "<init>", "()V", NULL, runtime);
            if (ctor) {
                push_ref(runtime->stack, exception);
                s32 ret = execute_method_impl(ctor, runtime);
                instance_release_from_thread(exception, runtime);
                if (ret == RUNTIME_STATUS_NORMAL) return exception;
                if (ret == RUNTIME_STATUS_EXCEPTION) {
                    /* Propagate a constructor's exception, not the unfinished object. */
                    exception = pop_ref(runtime->stack);
                    if (exception) return exception;
                }
            } else {
                instance_release_from_thread(exception, runtime);
            }
        }
    }
    jvm_printf("[ERROR]cannot construct dispatch exception: %s\n",
               STRS_CLASS_EXCEPTION[exception_type]);
    /* Allocation/GC-root failure must not turn into a NULL Java exception.
     * Use the rooted emergency object without allocating recursively. */
    if (runtime->jvm->out_of_memory_error) return runtime->jvm->out_of_memory_error;
    jvm_fatal_oom("dispatch-exception", sizeof(Instance));
}

s32 exception_throw_out_of_memory(Runtime *runtime) {
    Instance *exception = runtime->jvm->out_of_memory_error;
    if (!exception) exception = exception_create(JVM_ERROR_OUTOFMEMORY, runtime);
    if (exception) push_ref(runtime->stack, exception);
    return RUNTIME_STATUS_EXCEPTION;
}

Instance *exception_create_str(s32 exception_type, Runtime *runtime, c8 const *errmsg) {
#if _JVM_DEBUG_LOG_LEVEL > 5
    jvm_printf("create exception : %s\n", STRS_CLASS_EXCEPTION[exception_type]);
#endif
    if (!errmsg)errmsg = " ";
    Utf8String *uerrmsg = utf8_create_c(errmsg);
    Instance *jstr = jstring_create(uerrmsg, runtime);
    if (!jstr || instance_hold_to_thread(jstr, runtime) != 0) {
        utf8_destroy(uerrmsg);
        return NULL;
    }
    utf8_destroy(uerrmsg);
    RuntimeStack *para = stack_create(10);
    push_ref(para, jstr);
    instance_release_from_thread(jstr, runtime);
    Utf8String *clsName = utf8_create_c(STRS_CLASS_EXCEPTION[exception_type]);
    JClass *clazz = classes_load_get_with_clinit(NULL, clsName, runtime);
    utf8_destroy(clsName);
    Instance *ins = instance_create(runtime, clazz);
    if (!ins || instance_hold_to_thread(ins, runtime) != 0) {
        stack_destroy(para);
        return NULL;
    }
    instance_init_with_para(ins, runtime, "(Ljava/lang/String;)V", para);
    instance_release_from_thread(ins, runtime);
    stack_destroy(para);
    return ins;
}


void exception_throw(s32 exception_type, Runtime *runtime, c8 const *errmsg) {
    Instance *ex = exception_create_str(exception_type, runtime, errmsg);
    push_ref(runtime->stack, ex);
}

//===============================    lambda  ==================================


Instance *method_type_create(Runtime *runtime, Instance *jloader, Utf8String *desc) {
    JClass *cl = classes_load_get_with_clinit_c(NULL, STR_CLASS_JAVA_LANG_INVOKE_METHODTYPE, runtime);
    if (cl) {
        Instance *mt = instance_create(runtime, cl);
        if (!mt || instance_hold_to_thread(mt, runtime) != 0) return NULL;
        Instance *jstr_desc = jstring_create(desc, runtime);

        RuntimeStack *para = stack_create(10);

        push_ref(para, jloader);
        push_ref(para, jstr_desc);
        instance_init_with_para(mt, runtime, "(Ljava/lang/ClassLoader;Ljava/lang/String;)V", para);
        stack_destroy(para);
        instance_release_from_thread(mt, runtime);
        return mt;
    }
    return NULL;
}

Instance *method_handle_create(Runtime *runtime, MethodInfo *mi, s32 kind) {
    JClass *cl = classes_load_get_with_clinit_c(NULL, STR_CLASS_JAVA_LANG_INVOKE_METHODHANDLE, runtime);
    if (cl) {
        Instance *mh = instance_create(runtime, cl);
        if (!mh || instance_hold_to_thread(mh, runtime) != 0) return NULL;
        RuntimeStack *para = stack_create(10);
        push_int(para, kind);
        Instance *jstr_clsName = jstring_create(mi->_this_class->name, runtime);
        if (!jstr_clsName || instance_hold_to_thread(jstr_clsName, runtime) != 0) {
            instance_release_from_thread(mh, runtime);
            stack_destroy(para);
            return NULL;
        }
        push_ref(para, jstr_clsName);
        Instance *jstr_methodName = jstring_create(mi->name, runtime);
        if (!jstr_methodName || instance_hold_to_thread(jstr_methodName, runtime) != 0) {
            instance_release_from_thread(jstr_clsName, runtime);
            instance_release_from_thread(mh, runtime);
            stack_destroy(para);
            return NULL;
        }
        push_ref(para, jstr_methodName);
        Instance *jstr_methodDesc = jstring_create(mi->descriptor, runtime);
        if (!jstr_methodDesc || instance_hold_to_thread(jstr_methodDesc, runtime) != 0) {
            instance_release_from_thread(jstr_methodName, runtime);
            instance_release_from_thread(jstr_clsName, runtime);
            instance_release_from_thread(mh, runtime);
            stack_destroy(para);
            return NULL;
        }
        push_ref(para, jstr_methodDesc);
        push_ref(para, mi->_this_class->jloader);
        instance_init_with_para(mh, runtime,
                                "(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/ClassLoader;)V",
                                para);
        stack_destroy(para);
        instance_release_from_thread(mh, runtime);
        instance_release_from_thread(jstr_clsName, runtime);
        instance_release_from_thread(jstr_methodName, runtime);
        instance_release_from_thread(jstr_methodDesc, runtime);
        return mh;
    }
    return NULL;
}

Instance *method_handles_lookup_create(Runtime *runtime, JClass *caller) {
    JClass *cl = classes_load_get_with_clinit_c(NULL, STR_CLASS_JAVA_LANG_INVOKE_METHODHANDLES_LOOKUP, runtime);
    if (cl) {
        Instance *lookup = instance_create(runtime, cl);
        if (!lookup || instance_hold_to_thread(lookup, runtime) != 0) return NULL;
        RuntimeStack *para = stack_create(10);

        push_ref(para, insOfJavaLangClass_create_get(runtime, caller));
        instance_init_with_para(lookup, runtime, "(Ljava/lang/Class;)V", para);
        stack_destroy(para);
        instance_release_from_thread(lookup, runtime);
        return lookup;
    }
    return NULL;
}

//===============================    实例操作  ==================================


c8 *getFieldPtr_byName_c(Instance *instance, c8 const *pclassName, c8 const *pfieldName, c8 const *pfieldType, Runtime *runtime) {
    Utf8String *clsName = utf8_create_c(pclassName);
    //Class *clazz = classes_get(clsName);

    //set value
    Utf8String *fieldName = utf8_create_c(pfieldName);
    Utf8String *fieldType = utf8_create_c(pfieldType);
    c8 *ptr = getFieldPtr_byName(instance, clsName, fieldName, fieldType, runtime);
    utf8_destroy(clsName);
    utf8_destroy(fieldName);
    utf8_destroy(fieldType);
    return ptr;
}


c8 *getFieldPtr_byName(Instance *instance, Utf8String *clsName, Utf8String *fieldName, Utf8String *fieldType,
                       Runtime *runtime) {
    c8 *ptr = NULL;
    FieldInfo *fi = find_fieldInfo_by_name(clsName, fieldName, fieldType, instance->mb.clazz->jloader, runtime);

    if (fi) {
        if (fi->access_flags & ACC_STATIC) {
            ptr = getStaticFieldPtr(fi);
        } else {
            ptr = getInstanceFieldPtr(instance, fi);
        }
    }
    return ptr;
}

s32 getLineNumByIndex(CodeAttribute *ca, s32 offset) {
    s32 j;

    for (j = 0; j < ca->line_number_table_length; j++) {
        LineNumberTable *node = &(ca->line_number_table[j]);
        if (offset >= node->start_pc) {
            if (j + 1 < ca->line_number_table_length) {
                LineNumberTable *next_node = &(ca->line_number_table[j + 1]);

                if (offset < next_node->start_pc) {
                    return node->line_number;
                }
            } else {
                return node->line_number;
            }
        }
    }
    return -1;
}


void memoryblock_destroy(__refer ref) {
    MemoryBlock *mb = (MemoryBlock *) ref;
    if (!mb)return;
    //    if (utf8_equals_c(mb->clazz->name, "test/GuiTest$CallBack")) {
    //        garbage_dump_runtime();
    //        int debug = 1;
    //    }
    if (mb->type == MEM_TYPE_INS) {
        instance_destroy((Instance *) mb);
    } else if (mb->type == MEM_TYPE_ARR) {
        jarray_destroy((Instance *) mb);
    } else if (mb->type == MEM_TYPE_CLASS) {
        class_destroy((JClass *) mb);
    }
}

JavaThreadInfo *threadinfo_create() {
    JavaThreadInfo *threadInfo = jvm_calloc(sizeof(JavaThreadInfo));
    if (!threadInfo) return NULL;
    threadInfo->temp_roots.entries = threadInfo->temp_roots.inline_entries;
    threadInfo->temp_roots.capacity = GC_TEMP_ROOT_INLINE_CAPACITY;
    threadInfo->stacktrack = arraylist_create(16);
    threadInfo->lineNo = arraylist_create(16);
    threadInfo->objs_array = arraylist_create(256);
    threadInfo->jdwp_step = jvm_calloc(sizeof(JdwpStep));
    spin_init(&threadInfo->lock, 0);
    return threadInfo;
}

void threadinfo_destroy(JavaThreadInfo *threadInfo) {
    if (threadInfo->temp_roots.count > 0) {
        jvm_printf("[WARN] thread exit with %d held temp-root objects\n", threadInfo->temp_roots.count);
    }
    if (threadInfo->temp_roots.entries &&
        threadInfo->temp_roots.entries != threadInfo->temp_roots.inline_entries) {
        jvm_free(threadInfo->temp_roots.entries);
    }
    threadInfo->temp_roots.entries = NULL;
    threadInfo->temp_roots.count = 0;
    threadInfo->temp_roots.capacity = 0;
    arraylist_destroy(threadInfo->lineNo);
    arraylist_destroy(threadInfo->stacktrack);
    if (threadInfo->objs_array) {
        if (threadInfo->objs_array->length > 0) {
            jvm_printf("[WARN] thread exit with %d unspliced registered objects\n",
                       threadInfo->objs_array->length);
        }
        arraylist_destroy(threadInfo->objs_array);
        threadInfo->objs_array = NULL;
    }
#if _JVM_DEBUG_SLOW_CALL_PROFILE
    if (threadInfo->slow_call_ctx) {
        if (threadInfo->slow_call_ctx->nodes) jvm_free(threadInfo->slow_call_ctx->nodes);
        jvm_free(threadInfo->slow_call_ctx);
        threadInfo->slow_call_ctx = NULL;
    }
#endif
    jthreadlock_destroy(&threadInfo->pack);
    jvm_free(threadInfo->jdwp_step);
    spin_destroy(&threadInfo->lock);
    jvm_free(threadInfo);
}

s64 currentTimeMillis() {
    struct timespec tv;
    timespec_get(&tv, TIME_UTC);
    return ((s64) tv.tv_sec) * MILL_2_SEC_SCALE + tv.tv_nsec / NANO_2_MILLS_SCALE;
}

s64 nanoTime() {
    struct timespec tv;
    timespec_get(&tv, TIME_UTC);

    if (!nano_sec_start_at) {
        nano_sec_start_at = ((s64) tv.tv_sec) * NANO_2_SEC_SCALE + tv.tv_nsec;
    }
    s64 v = ((s64) tv.tv_sec) * NANO_2_SEC_SCALE + tv.tv_nsec;
    return v - nano_sec_start_at;
}

s64 threadSleep(s64 ms) {
    //wait time
    struct timespec req;
    //clock_gettime(CLOCK_REALTIME, &req);
    req.tv_sec = ms / MILL_2_SEC_SCALE;
    req.tv_nsec = (ms % MILL_2_SEC_SCALE) * NANO_2_MILLS_SCALE;
    //if notify or notifyall ,the thread is active again, rem record remain wait time
    struct timespec rem;
    rem.tv_sec = 0;
    rem.tv_nsec = 0;
    thrd_sleep(&req, &rem);
    return (rem.tv_sec * MILL_2_SEC_SCALE + rem.tv_nsec / NANO_2_MILLS_SCALE);
}

/* Per-thread temporary root table (replaces the old intrusive hold_next
 * chain). Repeated holds of the same object are refcounted, so overlapping
 * hold/release windows (e.g. JNI arg + return value) are now safe. */
s32 instance_hold_to_thread(Instance *ins, Runtime *runtime) {
    if (!runtime || !ins) return 0;
    GcTempRootTable *t = &runtime->thrd_info->temp_roots;
    s32 i;
    for (i = 0; i < t->count; i++) {
        if (t->entries[i].object == ins) {
            if (t->entries[i].ref_count == UINT32_MAX) {
                jvm_fatal_oom("temp-root-refcount", sizeof(GcTempRootEntry));
            }
            t->entries[i].ref_count++;
            return 0;
        }
    }
    if (t->count == t->capacity) {
        s32 ncap;
        GcTempRootEntry *ne;
        if (t->capacity > INT32_MAX / 2) {
            jvm_fatal_oom("temp-root-capacity", (size_t) t->capacity * sizeof(GcTempRootEntry));
        }
        ncap = t->capacity ? t->capacity * 2 : GC_TEMP_ROOT_INLINE_CAPACITY;
        if (t->entries == t->inline_entries) {
            ne = jvm_malloc((size_t) ncap * sizeof(GcTempRootEntry));
            if (ne)
                memcpy(ne, t->inline_entries,
                       (size_t) t->count * sizeof(GcTempRootEntry));
        } else {
            ne = t->entries
                     ? jvm_realloc(t->entries, (size_t) ncap * sizeof(GcTempRootEntry))
                     : jvm_malloc((size_t) ncap * sizeof(GcTempRootEntry));
        }
        if (!ne) {
            jvm_fatal_oom("temp-root-grow", (size_t) ncap * sizeof(GcTempRootEntry));
        }
        t->entries = ne;
        t->capacity = ncap;
    }
    t->entries[t->count].object = ins;
    t->entries[t->count].ref_count = 1;
    t->count++;
    return 0;
}

void instance_release_from_thread(Instance *ins, Runtime *runtime) {
    if (!runtime || !ins) return;
    GcTempRootTable *t = &runtime->thrd_info->temp_roots;
    s32 i;
    for (i = 0; i < t->count; i++) {
        if (t->entries[i].object == ins) {
            if (--t->entries[i].ref_count == 0) {
                t->entries[i] = t->entries[--t->count]; //swap-remove with tail
            }
            return;
        }
    }
    //releasing an object this thread never held: nothing to do (the old
    //chain walk had the same silent no-op behavior)
}

CStringArr *cstringarr_create(Instance *jstr_arr) {
    //byte[][] to c8**
    if (!jstr_arr)return NULL;
    CStringArr *cstr_arr = jvm_calloc(sizeof(CStringArr));
    cstr_arr->arr_length = jarray_length(jstr_arr);
    cstr_arr->arr_body = jvm_calloc(jarray_length(jstr_arr) * sizeof(__refer));
    s32 i;
    for (i = 0; i < cstr_arr->arr_length; i++) {
        s64 val = jarray_get_field(jstr_arr, i);
        Instance *jbyte_arr = (__refer) (intptr_t) val;
        if (jbyte_arr) {
            cstr_arr->arr_body[i] = jarray_body(jbyte_arr);
        }
    }
    return cstr_arr;
}

void cstringarr_destroy(CStringArr *cstr_arr) {
    jvm_free(cstr_arr->arr_body);
    jvm_free(cstr_arr);
}

ReferArr *referarr_create(Instance *jobj_arr) {
    if (!jobj_arr)return NULL;
    CStringArr *ref_arr = jvm_calloc(sizeof(CStringArr));
    ref_arr->arr_length = jarray_length(jobj_arr);
    ref_arr->arr_body = jvm_calloc(jarray_length(jobj_arr) * sizeof(__refer));
    s32 i;
    for (i = 0; i < ref_arr->arr_length; i++) {
        s64 val = jarray_get_field(jobj_arr, i);
        ref_arr->arr_body[i] = (__refer) (intptr_t) val;
    }
    return ref_arr;
}

void referarr_destroy(CStringArr *ref_arr) {
    jvm_free(ref_arr->arr_body);
    jvm_free(ref_arr);
}

void referarr_2_jlongarr(ReferArr *ref_arr, Instance *jlong_arr) {
    s32 i;
    for (i = 0; i < ref_arr->arr_length && i < jarray_length(jlong_arr); i++) {
        __refer ref = ref_arr->arr_body[i];
        jarray_set_field(jlong_arr, i, (intptr_t) ref);
    }
};


/**
 * load file less than 4G bytes
 */
s32 _loadFileContents(c8 const *file, ByteBuf *buf) {
    FILE *pFile;
    long lSize;
    c8 *buffer;
    size_t result;

    /* 若要一个byte不漏地读入整个文件，只能采用二进制方式打开 */
    pFile = fopen(file, "rb");
    if (pFile == NULL) {
        //jvm_printf("File error");
        return -1;
    }

    /* 获取文件大小 */
    fseek(pFile, 0, SEEK_END);
    lSize = ftell(pFile);
    rewind(pFile);

    /* 分配内存存储整个文件 */
    buffer = jvm_malloc((u32) lSize);
    if (buffer == NULL) {
        //jvm_printf("Memory error");
        return -1;
    }

    /* 将文件拷贝到buffer中 */
    result = fread(buffer, 1, lSize, pFile);
    if (result != lSize) {
        //jvm_printf("Reading error");
        return -1;
    }
    /* 现在整个文件已经在buffer中，可由标准输出打印内容 */
    //printf("%s", buffer);

    /* 结束演示，关闭文件并释放内存 */
    fclose(pFile);
    bytebuf_write_batch(buf, buffer, (s32) lSize);
    jvm_free(buffer);

    return 0;
}


ByteBuf *load_file_from_classpath(PeerClassLoader *cloader, Utf8String *path) {
    ByteBuf *bytebuf = NULL;
    s32 i, iret;
    for (i = 0; i < cloader->classpath->length; i++) {
        Utf8String *pClassPath = arraylist_get_value(cloader->classpath, i);
        if (isDir(pClassPath)) {
            //form file
            Utf8String *filepath = utf8_create_copy(pClassPath);
            utf8_pushback(filepath, '/');
            utf8_append(filepath, path);

            bytebuf = bytebuf_create(16);
            iret = _loadFileContents(utf8_cstr(filepath), bytebuf);
            utf8_destroy(filepath);
            //回收
            if (iret != 0) {
                bytebuf_destroy(bytebuf);
                bytebuf = NULL;
            }
        } else {
            //from jar
            bytebuf = bytebuf_create(16);
            iret = zip_loadfile(utf8_cstr(pClassPath), utf8_cstr(path), bytebuf);
            //回收
            if (iret != 0) {
                bytebuf_destroy(bytebuf);
                bytebuf = NULL;
            } else {
                break;
            }
        }
    }
    return bytebuf;
}


Instance *build_stack_element(Runtime *runtime, Runtime *target) {
    JClass *clazz = classes_load_get_with_clinit_c(NULL, STR_CLASS_JAVA_LANG_STACKTRACE, target);

    //ignore exception <init> stackframe
    JClass *throwable = classes_load_get_with_clinit_c(NULL, STR_CLASS_JAVA_LANG_THROWABLE, target);
    while (assignable_from(throwable, target->clazz)) {
        target = target->parent;
    }

    if (clazz) {
        ShortCut *shortcut = &runtime->jvm->shortcut;
        Instance *ins = instance_create(runtime, clazz);
        if (!ins || instance_hold_to_thread(ins, runtime) != 0) return NULL;
        instance_init(ins, runtime);
        c8 *ptr;
        //
        ptr = getInstanceFieldPtr(ins, shortcut->stacktrace_declaringClass);
        if (ptr) {
            Instance *name = jstring_create(target->clazz->name, runtime);
            setFieldRefer(ptr, name);
        }
        //
        ptr = getInstanceFieldPtr(ins, shortcut->stacktrace_methodName);
        if (ptr) {
            Instance *name = jstring_create(target->method->name, runtime);
            setFieldRefer(ptr, name);
        }
        //
        ptr = getInstanceFieldPtr(ins, shortcut->stacktrace_fileName);
        if (ptr) {
            Instance *name = jstring_create(target->clazz->source ? target->clazz->source : target->clazz->name, runtime);
            setFieldRefer(ptr, name);
        }
        //
        ptr = getInstanceFieldPtr(ins, shortcut->stacktrace_lineNumber);
        if (ptr) {
            if (target->method->is_native) {
                setFieldInt(ptr, -1);
            } else {
                setFieldInt(ptr, getLineNumByIndex(target->method->converted_code, (s32) (target->pc - target->method->converted_code->code)));
            }
        }
        if (target->parent && target->parent->parent) {
            ptr = getInstanceFieldPtr(ins, shortcut->stacktrace_parent);
            if (ptr) {
                Instance *parent = build_stack_element(runtime, target->parent);
                setFieldRefer(ptr, parent);
            }
        }
        ptr = getInstanceFieldPtr(ins, shortcut->stacktrace_declaringClazz);
        if (ptr) {
            setFieldRefer(ptr, insOfJavaLangClass_create_get(runtime, target->clazz));
        }

        instance_release_from_thread(ins, runtime);
        return ins;
    }
    return NULL;
}


void init_jni_func_table(MiniJVM *jvm) {
    jnienv.data_type_bytes = (s32 *) &DATA_TYPE_BYTES;
    jnienv.native_reg_lib = native_reg_lib;
    jnienv.native_remove_lib = native_remove_lib;
    jnienv.push_entry = push_entry_jni;
    jnienv.push_int = push_int_jni;
    jnienv.push_long = push_long_jni;
    jnienv.push_double = push_double_jni;
    jnienv.push_float = push_float_jni;
    jnienv.push_ref = push_ref_jni;
    jnienv.pop_ref = pop_ref_jni;
    jnienv.pop_int = pop_int_jni;
    jnienv.pop_long = pop_long_jni;
    jnienv.pop_double = pop_double_jni;
    jnienv.pop_float = pop_float_jni;
    jnienv.pop_entry = pop_entry_jni;
    jnienv.pop_empty = pop_empty_jni;
    jnienv.entry_2_int = entry_2_int_jni;
    jnienv.peek_entry = peek_entry_jni;
    jnienv.entry_2_long = entry_2_long_jni;
    jnienv.entry_2_refer = entry_2_refer_jni;
    jnienv.localvar_setRefer = localvar_setRefer_jni;
    jnienv.localvar_setInt = localvar_setInt_jni;
    jnienv.localvar_getRefer = localvar_getRefer_jni;
    jnienv.localvar_getInt = localvar_getInt_jni;
    jnienv.localvar_getLong_2slot = localvar_getLong_2slot_jni;
    jnienv.localvar_setLong_2slot = localvar_setLong_2slot_jni;
    jnienv.jthread_block_enter = jthread_block_enter;
    jnienv.jthread_block_exit = jthread_block_exit;
    jnienv.utf8_create = utf8_create;
    jnienv.utf8_create_part_c = utf8_create_part_c;
    jnienv.utf8_cstr = utf8_cstr;
    jnienv.utf8_destory = utf8_destroy;
    jnienv.jstring_2_utf8 = jstring_2_utf8;
    jnienv.jstring_create = jstring_create;
    jnienv.jstring_create_cstr = jstring_create_cstr;
    jnienv.cstringarr_create = cstringarr_create;
    jnienv.cstringarr_destory = cstringarr_destroy;
    jnienv.referarr_create = referarr_create;
    jnienv.referarr_destory = referarr_destroy;
    jnienv.referarr_2_jlongarr = referarr_2_jlongarr;
    jnienv.jvm_calloc = jvm_calloc;
    jnienv.jvm_malloc = jvm_malloc;
    jnienv.jvm_free = jvm_free;
    jnienv.jvm_realloc = jvm_realloc;
    jnienv.execute_method = execute_method;
    jnienv.find_methodInfo_by_name = find_methodInfo_by_name;
    jnienv.jarray_create_by_type_name = jarray_create_by_type_name;
    jnienv.jarray_create_by_type_index = jarray_create_by_type_index;
    jnienv.jarray_set_field = jarray_set_field;
    jnienv.jarray_get_field = jarray_get_field;
    jnienv.instance_hold_to_thread = instance_hold_to_thread;
    jnienv.instance_release_from_thread = instance_release_from_thread;
    jnienv.print_exception = print_exception;
    jnienv.garbage_refer_hold = gc_obj_hold;
    jnienv.garbage_refer_release = gc_obj_release;
    jnienv.runtime_create = runtime_create;
    jnienv.runtime_destory = runtime_destroy;
    jnienv.getLastSon = getLastSon;
    jnienv.thread_boundle = thread_boundle;
    jnienv.thread_unboundle = thread_unboundle;
    jnienv.thrd_current = thrd_current;
    jnienv.pairlist_create = pairlist_create;
    jnienv.pairlist_get = pairlist_get;
    jnienv.pairlist_put = pairlist_put;
    jnienv.jthread_get_daemon_value = jthread_get_daemon_value;
    jnienv.jthread_set_daemon_value = jthread_set_daemon_value;
    jnienv.get_jvm_state = get_jvm_state;
}

/**
 * 将锁添加到线程的持有锁列表（仅JDWP模式）
 */
void thread_add_held_lock(Runtime *runtime, MemoryBlock *lock) {
    JavaThreadInfo *threadInfo = runtime->thrd_info;

    // 只在JDWP启用时才维护锁列表
    if (!IS_JDWP_ENABLED(runtime)) {
        return;
    }

    //Publish the lazy debug list under the same lock used by JDWP readers.
    spin_lock(&threadInfo->lock);
    if (!threadInfo->held_locks) {
        threadInfo->held_locks = arraylist_create(0);
    }
    spin_unlock(&threadInfo->lock);

    // 使用 arraylist_index_of 检查是否已经存在（防止重复添加）
    if (arraylist_index_of(threadInfo->held_locks, arraylist_compare_ptr, lock) == -1) {
        arraylist_push_back(threadInfo->held_locks, lock);
        //        jvm_printf("[LOCK_TRACK] Thread %llx acquired lock %llx, total locks: %d\n",
        //                   (s64) (intptr_t) threadInfo->jthread, (s64) (intptr_t) lock,
        //                   threadInfo->held_locks->length);
    }
}

/**
 * 从线程的持有锁列表中移除锁（仅JDWP模式）
 */
void thread_remove_held_lock(Runtime *runtime, MemoryBlock *lock) {
    JavaThreadInfo *threadInfo = runtime->thrd_info;

    // 只在JDWP启用时才维护锁列表
    if (!IS_JDWP_ENABLED(runtime) || !threadInfo->held_locks) {
        return;
    }

    // 使用 arraylist_remove 直接移除
    if (arraylist_remove(threadInfo->held_locks, lock)) {
        //        jvm_printf("[LOCK_TRACK] Thread %llx released lock %llx, remaining locks: %d\n",
        //                   (s64) (intptr_t) threadInfo->jthread, (s64) (intptr_t) lock,
        //                   threadInfo->held_locks->length);

        // 检查是否是待释放的锁，如果是则主动检查挂起
        if (threadInfo->pending_release_lock == lock) {
            threadInfo->pending_release_lock = NULL;
            //            jvm_printf("[ACTIVE_SUSPEND] Thread %llx released pending lock %llx, checking suspension\n",
            //                       (s64) (intptr_t) threadInfo->jthread, (s64) (intptr_t) lock);
            // 主动检查是否需要挂起。lock-rescue 已把挂起计数清零，必须先
            // 重新武装计数再停驻，否则线程会在救援者的 5ms 轮询窗口内自由运行
            if (threadInfo->suspend_count == 0) {
                jthread_suspend(runtime); //0 -> 1
            }
            check_suspend_and_pause(runtime);
        }
    }
}

/**
 * 检查线程是否持有指定的锁（仅JDWP模式）
 */
s32 thread_owns_lock(Runtime *runtime, MemoryBlock *lock) {
    JavaThreadInfo *threadInfo = runtime->thrd_info;

    // 只在JDWP启用时才检查锁列表
    if (!IS_JDWP_ENABLED(runtime) || !threadInfo->held_locks) {
        return 0;
    }

    // 使用 arraylist_index_of 查找锁
    return arraylist_index_of(threadInfo->held_locks, arraylist_compare_ptr, lock) != -1;
}

/**
 * 查找持有指定锁的线程
 */
Runtime *find_thread_holding_lock(MiniJVM *jvm, MemoryBlock *lock) {
    // 注意：这里需要遍历所有线程，实际实现中应该维护一个线程列表
    // 这里作为简化实现，直接检查锁的拥有者
    if (lock && lock->thread_lock) {
        JavaThreadInfo *owner_info = (JavaThreadInfo *) lock->thread_lock->owner_thread;
        if (owner_info) {
            return owner_info->top_runtime;
        }
    }
    return NULL;
}

/**
 * 临时恢复被挂起的线程直到它释放指定的锁
 */
void temporarily_resume_for_lock_release(Runtime *suspended_thread, MemoryBlock *lock) {
    JavaThreadInfo *threadInfo = suspended_thread->thrd_info;

    //    jvm_printf("[LOCK_RESOLVE] Temporarily resuming thread %llx to release lock %llx\n",
    //               (s64) (intptr_t) threadInfo->jthread, (s64) (intptr_t) lock);

    // 保存原有的挂起状态
    s32 original_suspend_count = threadInfo->suspend_count;

    // 设置待释放的锁，用于主动挂起
    threadInfo->pending_release_lock = lock;

    // 临时恢复线程（用 jthread_resume 以便条件变量立刻唤醒挂起中的线程）
    while (threadInfo->suspend_count > 0) {
        jthread_resume(suspended_thread);
    }

    // 等待线程释放锁（或者主动挂起）
    s32 max_wait_cycles = 1000; // 最大等待周期
    s32 cycles = 0;

    while (thread_owns_lock(suspended_thread, lock) && cycles < max_wait_cycles) {
        threadSleep(5); // 等待5毫秒
        cycles++;

        // 检查是否已经主动挂起（jthread_unlock 的自挂起闭环）
        if (threadInfo->suspend_count > 0) {
            //            jvm_printf("[LOCK_RESOLVE] Thread %llx actively suspended after releasing lock %llx\n",
            //                       (s64) (intptr_t) threadInfo->jthread, (s64) (intptr_t) lock);
            //自挂起只补了 1 级计数，多级挂起（如 ALL 策略叠加）在这里补齐
            while (threadInfo->suspend_count < original_suspend_count) {
                jthread_suspend(suspended_thread);
            }
            return; // 已经主动挂起，无需继续等待
        }
    }

    //    if (cycles >= max_wait_cycles) {
    //        jvm_printf("[WARNING] Thread %llx did not release lock %llx within timeout\n",
    //                   (s64) (intptr_t) threadInfo->jthread, (s64) (intptr_t) lock);
    //    } else {
    //        jvm_printf("[LOCK_RESOLVE] Thread %llx successfully released lock %llx\n",
    //                   (s64) (intptr_t) threadInfo->jthread, (s64) (intptr_t) lock);
    //    }

    // 恢复原有的挂起状态（如果没有主动挂起）
    if (threadInfo->suspend_count == 0) {
        threadInfo->suspend_count = original_suspend_count;
    }

    // 清除待释放锁标记
    threadInfo->pending_release_lock = NULL;
}
