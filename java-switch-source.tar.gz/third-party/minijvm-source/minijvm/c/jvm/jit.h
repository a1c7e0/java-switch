//
// Created by root on 10/30/19.
//

#ifndef MINI_JVM_JIT_H
#define MINI_JVM_JIT_H
#ifdef __cplusplus
extern "C" {

#endif

#include "jvm.h"
#include "jvm_util.h"

#if __JVM_OS_IOS__ || __JVM_OS_CYGWIN__ || __JVM_ARCH_32__
#define JIT_ENABLE 0
#else
#define JIT_ENABLE 01
#endif

#define JIT_COMPILE_EXEC_COUNT 5000
#define JIT_DEBUG 0

#define SLJIT_CONFIG_AUTO 1
#define JIT_CODE_DUMP 0

enum {
    LOCAL_METHOD = 0,
    LOCAL_RUNTIME,
    LOCAL_STACK_SP,
    LOCAL_RUNTIME_PC,
    LOCAL_STACK,
    LOCAL_THREADINFO,
    LOCAL_R0, //for save_ip_sp
    LOCAL_R2, //for check_suspend
    /* JIT->JIT direct call scratch: survive the machine-code call, unlike
     * R0..R5 which the callee may clobber.  Never reuse LOCAL_R0/LOCAL_R2:
     * save_ip_sp and the safepoint helper own them. */
    LOCAL_CALL_CHILD,   //temporary CodeAttribute*, then pooled callee Runtime
    LOCAL_CALL_TARGET,  //callee MethodInfo*
    LOCAL_CALL_ENTRY,   //callee direct_entry, acquire-loaded
    LOCAL_CALL_STATUS,  //temporary local count, then callee RUNTIME_STATUS_*
    LOCAL_COUNT,
};

enum {
    JIT_GEN_UNKNOW = 0,
    JIT_GEN_COMPILING,
    JIT_GEN_ERROR,
    JIT_GEN_SUCCESS,
};


typedef void (*thread_suspend_check_func)();

struct _SwitchTable {
    struct _SwitchTable *next;
    s32 size; //table length
    struct V2PTable {
        s32 value; //for value
        s32 bc_pos; //for get label addr
        __refer jump_ptr;
    } *table;
};

void jit_init(CodeAttribute *ca);

void jit_destroy(Jit *jit);

void construct_jit(MethodInfo *method, Runtime *runtime);

s32 jit_invoke_from_jit(MethodInfo *method, Runtime *runtime);

/* On-stack replacement: compile the running method if needed and transfer
 * the live interpreted frame into the compiled body at the loop-header
 * bytecode position.  Returns the body's final RUNTIME_STATUS, or -1 when
 * no replacement happened (not compilable / busy / no label). */
s32 jit_osr_execute(Runtime *runtime, s32 bc_pos);

void jit_set_exception_jump_addr(Runtime *runtime, CodeAttribute *ca, s32 index);

#ifdef __cplusplus
}
#endif
#endif //MINI_JVM_JIT_H
